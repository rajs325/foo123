import java.io.*;
import java.util.*;

class Rel2Graph {
	public static void main(String args[]) {
		new Rel2Graph(args);
	}
	Rel2Graph(String args[]) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(args[0]));
            BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]));
            String line = "";
            while((line = br.readLine()) != null) { 
                String[] tokens = line.split("\\|");
                String ckey = tokens[0];
                String crels = tokens[1];
                /*remove [] brackets*/crels = crels.substring(1, crels.length() - 1);
                String crkeys[] = crels.split(",");
                //ArrayList<String> rkeys = new ArrayList<String>();
                //for(String crkey:crkeys) {
                //    rkeys.add(crkey);
                //}
                //relations.put(ckey, rkeys);
                bw.write("create (n:News{Name:\"" + ckey + "\"});\n");
                for(String rel:crkeys) {
                    bw.write("merge (n:News{Name:\"" + rel + "\"});\n");
                }
                for(String rel:crkeys) {
                    bw.write("MATCH (a:News),(b:News) WHERE a.Name = '" + ckey + "' AND b.Name = '" + rel + "' CREATE (a)-[r:RELATED_TO]->(b) RETURN type(r);\n");
                }
            }
            br.close();
            bw.close();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}