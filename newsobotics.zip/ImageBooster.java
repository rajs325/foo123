//package com.newsobotics.rss;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;


public class ImageBooster {
    private volatile LinkedHashMap<String, LinkedHashMap<String,RSSEntry>> content = null;
    //private volatile LinkedHashMap<String, LinkedHashMap<String,Integer>> srcStats = null;

    //private volatile LinkedHashMap<String,Integer>         wrdStats = null;
    //private volatile LinkedHashMap<String,HashSet<String>> wrdSeqns = null;
    //private volatile LinkedHashMap<String,Integer> sources = null;
    HashSet<String> dupes;

    HashMap<String,String>imageURLs=null;
    int imageCacheHits = 0;
    int imageCacheMiss = 0;
    HashSet<String> hits;

    //HashMap seqns = new HashMap<String,Integer>();
    //HashMap kgraph = new HashMap<String,Integer>();
    //HashMap knoise = new HashMap<String,Integer>();
    //POSTaggingExample tagger = new POSTaggingExample();
    //HashMap<Integer, HashSet<String>> contextBags;
    //HashMap<HashSet<String>, ArrayList<Integer>> bagContexts;
    private static int runCount = 0;

    public static void main(String[] args) {
        if(args.length < 1) {
            System.out.println("java ImageBooster <rss-feed-list-file.txt>\n");
            return;
        }
        ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);

        Runnable task1 = () -> {
            runCount++;
            System.err.println("Running...ImageBooster - runCount : " + runCount);
            new ImageBooster(args);
        };

        // init Delay = 5, repeat the task every 1 second
        ScheduledFuture<?> scheduledFuture = ses.scheduleAtFixedRate(task1, 5, 60*15, TimeUnit.SECONDS);

        while (true) {
            System.err.println("ImageBooster :" + runCount);
            try {
                Thread.sleep(1000);
            }catch(Exception e) {
                e.printStackTrace();
            }
            //if (runCount == 5) {
            //    System.err.println("ImageBooster: Count is 5, cancel the scheduledFuture!");
            //    scheduledFuture.cancel(true);
            //    ses.shutdown();
            //    break;
            //}
        }
    }

    ImageBooster(String args[]) {
        String feeds = args[0];
        String source = "";
        content  = new LinkedHashMap();
        //srcStats = new LinkedHashMap();
        //wrdStats = new LinkedHashMap();
        //wrdSeqns = new LinkedHashMap();
        //sources = new LinkedHashMap();
        dupes = new HashSet<String>();
        //seqns = new HashMap<String,Integer>();
        //contextBags = new HashMap<Integer, HashSet<String>>();
        //bagContexts = new HashMap<HashSet<String>, ArrayList<Integer>>();

        int sourceCount = 0;
        
        try {
            loadImageURLCache();

            BufferedReader br = new BufferedReader(new FileReader(feeds));
            String line = "";
            boolean imageBoosting = false;
            while((line = br.readLine()) != null) {
                if(line.isEmpty() == true || line.startsWith("#") == true) {
                    if(line.startsWith("##") == true || line.startsWith("#@") == true) {
                        //System.out.println(line);
                        source = line.substring(2);
                        //sources.put(source, new Integer(sourceCount));
                        sourceCount++;
                    }

                    if(line.startsWith("#@")) {
                        imageBoosting = true;
                    } else if(line.startsWith("##")){
                        imageBoosting = false;
                    }

                    //System.out.println(imageBoosting + ":" + line);
                    continue;
                }
                if(imageBoosting == true) {
                    String token[] = line.split("\\|");
                    String category = token[0];
                    String rssURL = token[1];
                    //RSSReader rd = new RSSReader(new String[] {token[0], token[1]});
                    XMLParserSAX rd = new XMLParserSAX(new String[] {source, category, rssURL});
                    //aggregate(category, rd.getEntries());
                    aggregate2(category, rd.getEntries());
                }
            }

            br.close();

            unloadImageURLCache();
            //NewsSorter s = new NewsSorter(content);
            //s.sort();
            //NewsPrinter p = new NewsPrinter(content, srcStats, null);
            // p.print(args[1]);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    private void loadImageURLCache() {
        //printedItems = new ArrayList<Integer>();
        imageURLs = new HashMap<String,String>();
        //System.err.println(imageURLs);
        hits = new HashSet<String>();
        int lineNumber = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader("image-urls-new.txt"));
            String line = "";
            while((line = br.readLine()) != null) {
                lineNumber++;
                String[] tokens = line.split("\\|");
                if(tokens.length >= 2) {
                    tokens[0] = tokens[0].trim();
                    tokens[1] = tokens[1].trim();
                    imageURLs.put(tokens[0], tokens[1]);
                }
            }
            br.close();
            System.err.println(imageURLs);
        }catch(Exception e) {
            e.printStackTrace();
            System.err.println("image-urls.txt("+lineNumber+"):Error insufficient tokens");
        }
    }

    private void unloadImageURLCache() {
        //System.err.println(imageURLs);
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("image-urls-new.txt"));
            String line = "";
            List<String> keys = new ArrayList<>(imageURLs.keySet());
            for(String key : keys) {
                if(hits.contains(key)) {
                    String imageURL = (String)imageURLs.get(key);
                    bw.write(key + "|" + imageURL + "\n");
                }
            }
            bw.close();

            bw = new BufferedWriter(new FileWriter("image-urls.txt"));
            line = "";
            keys = new ArrayList<>(imageURLs.keySet());
            for(String key : keys) {
                if(hits.contains(key)) {
                    String imageURL = (String)imageURLs.get(key);
                    bw.write(key + "|" + imageURL + "\n");
                }
            }
            bw.close();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    /*void aggregate(String category, List<RSSEntry> entries) {
        if(entries == null) {
            return;
        }
        try {
            String fileName = category +".rss.txt";
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true));
            for(RSSEntry entry : entries) {
                bw.write(entry.toString() + "\n");
            }
            bw.close();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }*/

    void aggregate2(String category, List<RSSEntry> entries) {
        if(entries == null) {
            return;
        }

        for(RSSEntry entry : entries) {
            //1. store content according to its category.
            String key = "" + ((Integer)entry.getBarcode()).intValue();
            //String link = entry.getLink();
            String source = entry.getSource();

            boostImage(entry);

            LinkedHashMap map = content.get(category);
            if(map == null) {
                map = new LinkedHashMap<String, RSSEntry>();
                content.put(category, map);
            }
            map.put(key, entry);

            //2. store content word statistics for all categories
            /*title = entry.getTitle() + " " + entry.getDescription();
            String words[] = title.split(" ");
            //int nwords = words.length;
            for(String word: words) {
                word = word.toLowerCase();
                Integer wc = (Integer)wrdStats.get(word);
                if(wc == null) {
                    wc = new Integer(1);
                } else {
                    wc = new Integer(wc.intValue() + 1);
                }
                if(isAlphaNumeric(word)) {
                    wrdStats.put(word, wc);
                }
            }*/

            //3. store content source statistics to its category.
            /*LinkedHashMap countMap = srcStats.get(category);
            if(countMap == null) {
                countMap = new LinkedHashMap<String, Integer>();
                srcStats.put(category, countMap);                
            }
            Integer count = (Integer)countMap.get(source);
            if(count == null) {
                count = new Integer(1);
            } else {
                int value = count.intValue();
                count = new Integer(++value);
            }
            countMap.put(source, count);*/
        }
    }

    private String boostImage(RSSEntry entry) {
        String source = entry.getSource();
        String mediaURL = entry.getMediaURL();
        //if(source.equals("DAILYMAIL") == false) {
        //    return mediaURL;
        //}

        String pageURL = entry.getLink();
        pageURL = pageURL.trim();
        String imageURL = null;
        //Extract twitter:image or og:image from the page
        imageURL = imageURLs.get(pageURL);
        if(imageURL == null) {
            //imageCacheMiss++;
            Curl curl = new Curl(pageURL);
            String contents = curl.getContent();
            //System.err.println(contents);
            imageURL = extractImageURL(contents);
            System.err.println(pageURL + "|" + imageURL);
            imageURLs.put(pageURL, imageURL);
        } else {
            //imageCacheHits++;
        }
        hits.add(pageURL);

        if(imageURL != null) {
            entry.setMediaType("image");
            entry.setMediaURL(imageURL);
        }
        return imageURL;
    }

    private String extractImageURL(String aPageContent) {
        //System.err.println(aPageContent);

        String imageURL = null;
        String ogstartPattern  = "\"og:image\"";
        String twstartPattern1 = "\"twitter:image:src\"";
        String twstartPattern2 = "\"twitter:image\"";
        int ogstartIndex  = aPageContent.indexOf(ogstartPattern);
        int twstartIndex1 = aPageContent.indexOf(twstartPattern1);
        int twstartIndex2 = aPageContent.indexOf(twstartPattern2);
        if(ogstartIndex != -1) {
            ogstartIndex += ogstartPattern.length();
            ogstartPattern = "content=\"";
            ogstartIndex = aPageContent.indexOf(ogstartPattern, ogstartIndex);
            ogstartIndex += ogstartPattern.length();
            String endPattern = "\"";
            int endIndex = aPageContent.indexOf(endPattern, ogstartIndex);
            if(endIndex != -1) {
                imageURL = aPageContent.substring(ogstartIndex, endIndex);
            }
        } else if(twstartIndex1 != -1) {
            twstartIndex1 += twstartPattern1.length();
            twstartPattern1 = "content=\"";
            twstartIndex1 = aPageContent.indexOf(twstartPattern1, twstartIndex1);
            twstartIndex1 += twstartPattern1.length();
            String endPattern = "\"";
            int endIndex = aPageContent.indexOf(endPattern, twstartIndex1);
            if(endIndex != -1) {
                imageURL = aPageContent.substring(twstartIndex1, endIndex);
            }
        } else if(twstartIndex2 != -1) {
            twstartIndex2 += twstartPattern2.length();
            twstartPattern2 = "content=\"";
            twstartIndex2 = aPageContent.indexOf(twstartPattern2, twstartIndex1);
            twstartIndex2 += twstartPattern2.length();
            String endPattern = "\"";
            int endIndex = aPageContent.indexOf(endPattern, twstartIndex2);
            if(endIndex != -1) {
                imageURL = aPageContent.substring(twstartIndex2, endIndex);
            }
        }

        return imageURL;
    }
}
