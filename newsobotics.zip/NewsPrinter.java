import java.io.*;
import java.util.*;
import java.time.*;
import java.awt.Point;

//import com.rometools.rome.feed.synd.*;
//import com.rometools.rome.io.*;


public class NewsPrinter {
	public static final String FMT_CSV  = "CSV";
	public static final String FMT_HTML = "HTML";
	LinkedHashMap<String,LinkedHashMap<String,RSSEntry>> content;
	//LinkedHashMap<String,LinkedHashMap<String,Integer>> srcStats;
	//LinkedHashMap<String,Integer> wrdStats;
	//LinkedHashMap<String,Integer> sources;
	HashSet<String> dupes;
	//ArrayList<Integer> printedItems;
	HashMap<String,String>imageURLs=null;
	int imageCacheHits = 0;
	int imageCacheMiss = 0;
	HashSet<String> hits;

	private static int MAX_SLOTS = 40;
	//private static int MAX_SLOTS_25 = MAX_SLOTS / 4;
	//private static int MAX_SLOTS_50 = MAX_SLOTS / 2;
	//private static int MAX_SLOTS_75 = MAX_SLOTS * 3 / 4;
	private static int MAX_SLOTS_25 = MAX_SLOTS / 6;
	private static int MAX_SLOTS_50 = MAX_SLOTS_25 * 2;
	private static int MAX_SLOTS_75 = MAX_SLOTS_25 * 3;

	NewsPrinter(LinkedHashMap<String,LinkedHashMap<String,RSSEntry>> aContent,
		LinkedHashMap<String,LinkedHashMap<String,Integer>> asrcStats,
		LinkedHashMap<String,Integer> awrdStats) {
		content = aContent;
		//srcStats = asrcStats;
		//wrdStats = awrdStats;
		//sources = aSources;

		dupes = new HashSet<String>();
	}

	private void loadImageURLCache() {
		//printedItems = new ArrayList<Integer>();
		imageURLs = new HashMap<String,String>();
		//System.err.println(imageURLs);
		hits = new HashSet<String>();
		int lineNumber = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader("image-urls.txt"));
			String line = "";
			while((line = br.readLine()) != null) {
				lineNumber++;
				String[] tokens = line.split("\\|");
				if(tokens.length >= 2) {
					tokens[0] = tokens[0].trim();
					tokens[1] = tokens[1].trim();
					imageURLs.put(tokens[0], tokens[1]);
				}
			}
			br.close();
			//System.err.println(imageURLs);
		}catch(Exception e) {
			e.printStackTrace();
			//System.err.println("image-urls.txt("+lineNumber+"):Error insufficient tokens");
		}
	}

	private void unloadImageURLCache() {
		//System.err.println(imageURLs);
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("image-urls.txt"));
			String line = "";
			List<String> keys = new ArrayList<>(imageURLs.keySet());
			for(String key : keys) {
				if(hits.contains(key)) {
					String imageURL = (String)imageURLs.get(key);
					bw.write(key + "|" + imageURL + "\n");
				}
			}
			bw.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	void print(String format) {
		
		loadImageURLCache();
		//if(format.equals(NewsPrinter.FMT_CSV)) {
		printESJSON();
		//} else {
		printNewsPaperHTML();
		//printMasonryHTML();			
		//}

		int total = imageCacheMiss + imageCacheHits;
		/* Avoid NAN */ total = total == 0 ? 1 : total;
		double misses = (double)imageCacheMiss * 100 / total;
		double hits = (double)imageCacheHits * 100 / total;
		System.err.println("cache miss:" + misses + "%, cache hits:" + hits + "%");

		//unloadImageURLCache();
	}

	private void printESJSON() {
		//System.out.println(content);
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("news-es.json"));
			Set<String> categories = content.keySet();
			int seqno = 1;
			for(String category : categories) {
				LinkedHashMap<String,RSSEntry> map = content.get(category);
				List<String> keys = new ArrayList<>(map.keySet());
				for(String key : keys) {
					RSSEntry entry = (RSSEntry)map.get(key);
					Integer barcode = entry.getBarcode();
					String title = entry.getTitle();
					String link = entry.getLink();
					String description = entry.getDescription();
					int dlength = description.length();
					String source = entry.getSource();
					String ago = entry.getReadableDate();
					boolean isOldNews = ago.contains("week") || ago.contains("month");

					Date then = entry.getDate();
					Date now = new Date();
					if(then == null) {
						then = now;
					}
					Duration duration = Duration.between(now.toInstant(), then.toInstant());
					long ndays = Math.abs(duration.toDays());
					long nmonths= Math.abs(ndays / 30);

					boolean alreadyFound = dupes.contains(key);

					if(/*title.length() > 50 && */isOldNews == false && /*hasPredictions == true && */alreadyFound == false && /*rlimit != 0 && mediaURL != null && */dlength > 32) {
						//String category = entry.getCategory();
						String mediaURL = boostImage(entry);
						//String mediaURL = entry.getMediaURL();
						title = title.replaceAll("\"", "\\\\\"");
						title = title.replaceAll("\n", "");
						description = description.replaceAll("\",", ",");;
						description = description.replaceAll("\"", "\\\\\"");;
						description = description.replaceAll("\n", "");
						description = description.replaceAll("\"\n", "");

						String sseqno = "" + seqno;
						int digits = sseqno.length();
						String fills [] = { "", "0000", "000", "00", "0", "" };
						sseqno = fills[digits] + sseqno;

						String esjson = "{ \"index\":{} }\n"+
							"{\"category\":\""       + category +
						    "\", \"seqno\":\""       + sseqno +
						    "\", \"barcode\":\""     + barcode +
							"\", \"source\":\""      + source +
							"\", \"title\":\""       + title +
							"\", \"link\":\""        + link +
							"\", \"mediaURL\":\""    + mediaURL +
							"\", \"description\":\"" + description +
							"\", \"ago\":\""         + ago +
							"\"}\n";
						bw.write(esjson);
						seqno++;
	
						dupes.add(key);
					}
				}
			}
			bw.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


	private void printNewsPaperHTML() {
		//System.out.println(content);
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("news-scripts.js"));
			Set<String> categories = content.keySet();
			dupes.clear();
			int ccount = 0;
			for(String category : categories) {
				LinkedHashMap<String,RSSEntry> map = content.get(category);
				List<String> keys = new ArrayList<>(map.keySet());
				bw.write("var data" + (ccount + 1) + "= [\n");
				for(String key : keys) {
					RSSEntry entry = (RSSEntry)map.get(key);
					Integer barcode = entry.getBarcode();
					String title = entry.getTitle();
					String link = entry.getLink();
					String mediaURL = entry.getMediaURL();
					String description = entry.getDescription();
					int dlength = description.length();
					String source = entry.getSource();
					String ago = entry.getReadableDate();
					boolean isOldNews = ago.contains("week") || ago.contains("month");

					boolean alreadyFound = dupes.contains(key);

					if(/*title.length() > 50 && */isOldNews == false && /*hasPredictions == true && */alreadyFound == false && /*rlimit != 0 && mediaURL != null && */dlength > 32) {

						title = title.replaceAll("\"", "\\\\\"");
						title = title.replaceAll("\n", "");
						description = description.replaceAll("\",", ",");;
						description = description.replaceAll("\"", "\\\\\"");;
						description = description.replaceAll("\n", "");
						description = description.replaceAll("\"\n", "");

						ArrayList<RSSEntry> children = entry.getChildren();
						String ckeys = "";
						if(children != null && children.size() > 0) {
							ckeys = "\"children\":[";
							for(RSSEntry child:children) {
								//ckeys += child.getBarcode() + ", ";
								String ctitle = child.getTitle();
								ctitle = ctitle.replaceAll("\"", "\\\\\"");
								ctitle = ctitle.replaceAll("\n", "");
								String clink = child.getLink();
								ckeys += "{\"title\":\""  + ctitle + "\", \"link\":\"" + clink + "\"}, ";
							}
							ckeys += "]";
						}

						String esjson =
							"\t{\"category\":\""     + category +
						    "\", \"barcode\":\""     + barcode +
							"\", \"source\":\""      + source +
							"\", \"title\":\""       + title +
							"\", \"link\":\""        + link +
							"\", \"mediaURL\":\""    + mediaURL +
							"\", \"description\":\"" + description +
							"\", \"ago\":\""         + ago +
							//\"meta\":\""        + aKey + ":" + rels + ":" + score + ":" + ckeys +
							"\", "                   + ckeys + "},\n";

						bw.write(esjson);
						dupes.add(key);
					}
				}
				bw.write("];\n");
				ccount++;

			}

			ccount = 0;
			for(String category : categories) {
				LinkedHashMap map = content.get(category);
				int size = map.size();
				List<String> keys = new ArrayList<>(map.keySet());
				int kcount = keys.size();
				if(kcount < 12) {
					continue;
				}
			    String tcategory = removePunctuations(category);
			    //System.out.println("<li class=\"nav-item\">\n  <a class=\"nav-link\" href=\"#" + category +"\">"+category+"</span></a></li>\n");
				bw.write("$(\"#" + tcategory + "\").ready(function(){\n" +
	    			"\tfetch('" + tcategory + "', data" + (ccount + 1) + ", '" + category + "');\n" + "});\n");
				ccount++;
			}
			bw.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	/*private void printNewsPaperHTML2() {
		//System.out.println(content);
		//analyzeStats();
		Set<String> categories = content.keySet();
		int ccount = 0;

		LinkedHashMap<String,RSSEntry> predicts = new LinkedHashMap<String,RSSEntry>();

		for(String category : categories) {
			LinkedHashMap map = content.get(category);
			int size = map.size();
			List<String> keys = new ArrayList<>(map.keySet());
			int kcount = keys.size();
			if(kcount < 12) {
				continue;
			}
		    //System.out.println("<li class=\"nav-item\">\n  <a class=\"nav-link\" href=\"#" + category +"\">"+category+"</span></a></li>\n");
		    String tcategory = removePunctuations(category);
		    //System.out.println("\t<span class=\"card-text\"><a href=\"#\" onClick=\"myFunction('"+tcategory+"')\">"+category+"</a>&nbsp;|&nbsp;</span>");

			int index = 0;
			while(index < kcount) {
				String key = keys.get(index);
				RSSEntry entry = (RSSEntry)map.get(key);
				String title = entry.getTitle();
				String description = entry.getDescription();
				title = title.toLowerCase();
				description = description.toLowerCase();
				if(title.contains("predict") || description.contains("predict") || title.contains("might") || description.contains("might")) {
					predicts.put(key, entry);
				}
				index++;
			}
		}

		//System.out.println("\t<span class=\"card-text\"><a href=\"#\" onClick=\"myFunction('Predictions')\">Predictions</a>&nbsp;|&nbsp;</span>");
		//content.put("Predictions", predicts);

		ccount = 0;
		for(String category : categories) {
			LinkedHashMap map = content.get(category);
			int size = map.size();
			List<String> keys = new ArrayList<>(map.keySet());
			int kcount = keys.size();
			if(kcount < 12) {
				continue;
			}
		    //System.out.println("<li class=\"nav-item\">\n  <a class=\"nav-link\" href=\"#" + category +"\">"+category+"</span></a></li>\n");
		    category = removePunctuations(category);
		    //System.out.println("\t<div id=\""+category+"\"></div>");
		}
		ccount = 0;
		for(String category : categories) {
			LinkedHashMap map = content.get(category);
			int size = map.size();
			List<String> keys = new ArrayList<>(map.keySet());
			int kcount = keys.size();
			if(kcount < 12) {
				continue;
			}
		    String tcategory = removePunctuations(category);
		    //System.out.println("<li class=\"nav-item\">\n  <a class=\"nav-link\" href=\"#" + category +"\">"+category+"</span></a></li>\n");
			System.out.println("$(\"#" + tcategory + "\").ready(function(){\n" +
    			"\tfetch('" + tcategory + "', data" + (ccount + 1) + ", '" + category + "');\n" + "})\n");
			ccount++;
		}
		categories = content.keySet();
	    //<!--<form class="form-inline my-2 my-lg-0">
	    //  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
	    //  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
	    //</form>-->
	    //System.out.println("</div>\n");

  		ccount = 0;
  		//System.out.println("<div class=\"container-fluid\">");
		for(String category : categories) {
			LinkedHashMap map = content.get(category);
			int size = map.size();
			List<String> keys = new ArrayList<>(map.keySet());
			int kcount = keys.size();
			if(kcount < 12) {
				continue;
			}

			
			//LinkedHashMap limits = srcStats.get(category);
  			//System.out.println("<h1 class=\"border-bottom\" id=\"" + category + "\"><a href=\"#top\">&#10514;</a>&nbsp;&nbsp;" + category + "&nbsp;(" + size + ")</h1>\n");
			//System.out.println("<div class=\"card-columns\" style=\"padding:10px 20px\">");
			System.out.println("var data" + (ccount + 1) + "= [\n");
			ccount++;
			int count = 0;
			int index = 0;
			String source = "";
			String previousSource = "";
			int limit = 0;
			RSSEntry entry = null;
			String key = "";

			//printedItems.clear();

			dupes.clear();
			while(index < kcount) {
				key = keys.get(index);
				entry = (RSSEntry)map.get(key);
				String title = entry.getTitle();
				//source = entry.getSource();
				String mediaURL = entry.getMediaURL();
				boolean isVideo = mediaURL != null && mediaURL.endsWith("mp4");
				String link = entry.getLink();
				String description = entry.getDescription();
				int dlength = description.length();
				//Integer barcode = entry.getBarcode();
				//Point point = entry.getPoint();
				String ago = entry.getReadableDate();
				//double score = entry.getScore();
				boolean isOldNews = ago.contains("week") || ago.contains("month");
				//boolean hasPredictions = title.contains("predict") || title.contains("might") ||
				//	description.contains("predict") || description.contains("might");

				//Date then = entry.getDate();
				//Date now = new Date();
				//if(then == null) {
				//	then = now;
				//}
				//Duration duration = Duration.between(now.toInstant(), then.toInstant());
				//long ndays = Math.abs(duration.toDays());
				//long nmonths= Math.abs(ndays / 30);

				boolean alreadyFound = dupes.contains(key);

				ArrayList<String> kritems = entry.getRelatedEntities();
				//ArrayList<Double> rscores = entry.getRelatedScores();
				int rlimit = kritems.size();
				for(int rindex = 0; rindex < rlimit; rindex++) {
					if(dupes.contains("" + kritems.get(rindex))) {
						alreadyFound = true;
					}
				}

				if(title.length() > 50 && isOldNews == false && hasPredictions == true && alreadyFound == false && rlimit != 0 && mediaURL != null && dlength > 32) {

					//mediaURL = boostImage(entry);
					printJSON(count, category, map, key, entry);

					dupes.add(key);
					/*if(count < MAX_SLOTS_25) {
						printCardXL(count, category, map, key, entry);
					}else if(count < MAX_SLOTS_50) {
						printCardL(count, category, map, key, entry);
					}else if(count < MAX_SLOTS_75) {
						printCardM(count, category, map, key, entry);
					} else {
						printCardS(count, category, map, key, entry);
					}*/

					/*String imagePrefix = "";
					if(category.equals("Videos") == false && mediaURL != null && isVideo == false) {
						imagePrefix = "<img class=\"card-image-top\" style=\"width:100%;padding-bottom:10px;\" src=\"" + mediaURL + "\" alt=\"" + "\"></img>\n";
					}
					System.out.println("<div class=\"card border-top-0 border-left-0 border-right-0 border-3\">" +
						imagePrefix + "  <h4 class=\"card-title\"><a href=\"" + link + "\" target=\"_blank\">" + title + "</a></h4>\n" +
						"<p><span class=\"badge badge-primary\">" + source + "</span>&nbsp;" + "<span class=\"badge ago\">" + ago + "</span></p>\n" +
						"<p class=\"card-text h5\">" + description + "&nbsp;" + "<!--(" + dlength + --barcode + "," + kritems-- + ")-->" + "</p><br/>\n");


					rlimit = rlimit > 5 ? 5 : rlimit;
					for(int rindex = 0; rindex < rlimit; rindex++) {
						Integer kritem = kritems.get(rindex);
						Double rscore = rscores.get(rindex);
						String rkey = "" + kritem.intValue();
						RSSEntry ritem = (RSSEntry)map.get(rkey);
						if(ritem != null) {
							String rtitle = ritem.getTitle();
							String rlink = ritem.getLink();
							System.out.println("  <div class=\"card card-text small border-2 border-left-0 border-right-0 border-bottom-0\"><a href=\"" +
								rlink + "\" target=\"_blank\">" + rtitle + "</a>&nbsp;("+ rscore.intValue() + ")</div>");
							dupes.add(rkey);
						}
					}

					System.out.println("</div>\n");
					//printedItems.add(new Integer(index));
					count++;
				}

				//if(alreadyFound == false) {
				//	dupes.add(barcode);
				//clea}

				if(category.equals("Predictions") == false) {
					if(source.equals(previousSource) == false) {
						limit = ((Integer)limits.get("#"+source)).intValue();
						//limit = limit / 2;
						//limit = limit == 0 ? 1 : limit;
						limit = index + limit;
					}

					if(index >= limit) {
						while(index < kcount && source.equals(previousSource)) {
							key = keys.get(index);
							entry = (RSSEntry)map.get(key);
							source = entry.getSource();
							index++;
						}
					} else {
						previousSource = source;
						index++;
					}
				} else {
					index++;
				}
				index++;
			}
			//System.out.println("</div>");
			System.out.println("];\n");
		}
		//System.out.println("</div>");				
		System.out.println("\n");				
		ccount = 0;
		for(String category : categories) {
			LinkedHashMap map = content.get(category);
			int size = map.size();
			List<String> keys = new ArrayList<>(map.keySet());
			int kcount = keys.size();
			if(kcount < 12) {
				continue;
			}
		    String tcategory = removePunctuations(category);
		    //System.out.println("<li class=\"nav-item\">\n  <a class=\"nav-link\" href=\"#" + category +"\">"+category+"</span></a></li>\n");
			System.out.println("$(\"#" + tcategory + "\").ready(function(){\n" +
    			"\tfetch('" + tcategory + "', data" + (ccount + 1) + ", '" + category + "');\n" + "});\n");
			ccount++;
		}
	}*/
    private static final String punctuations [] = {
        "\\.", //is a period or full stop
        "\\,", //is a comma
        "\\?", //is a question mark
        "\\!", //is an exclamation mark
        "\\'", "’", //is an apostrophe or single quote mark
        "\"", //is a quotation mark/inverted comma
        ":", //is a colon
        ";", //is a semicolon
        "\\.\\.\\.", //is an ellipsis mark
        "\\-", //is a hyphen
        "\\–", //is an en dash
        "\\—", //is an em dash
        "\\(", "\\)", //are parentheses or curved brackets
        "\\[", "\\]", //are brackets or square brackets.
        "\r\n", "\n",
        " ", "\\&",
    };
    private String removePunctuations(String word) {
        int limit = punctuations.length;
        String nothing = "";
        for(int index = 0; index < limit; index++) {
            String punctuation = punctuations[index];
            //if(word.contains(punctuation)) {
            word = word.replaceAll(punctuation, nothing);
            //}
        }
        return word;
    }
	private void printJSON(int aCount, String aCategory, LinkedHashMap<String,RSSEntry> aMap, String aKey, RSSEntry aEntry) {
		String title = aEntry.getTitle();
		String source = aEntry.getSource();
		String mediaURL = aEntry.getMediaURL();
		boolean isVideo = mediaURL != null && mediaURL.endsWith("mp4");
		String link = aEntry.getLink();
		String description = aEntry.getDescription();
		int dlength = description.length();
		Integer barcode = aEntry.getBarcode();
		//Point point = aEntry.getPoint();
		String ago = aEntry.getReadableDate();
		//double score = entry.getScore();
		double sentiment = aEntry.getSentiment();
		boolean isOldNews = ago.contains("week") || ago.contains("month");
		boolean hasPredictions = title.contains("predict") || title.contains("might") ||
			description.contains("predict") || description.contains("might");

		title = title.replaceAll("\"", "\\\\\"");
		title = title.replaceAll("\n", "");
		description = description.replaceAll("\",", ",");;
		description = description.replaceAll("\"", "\\\\\"");;
		description = description.replaceAll("\n", "");
		description = description.replaceAll("\"\n", "");

		//ArrayList<String> rels = aEntry.getRelatedEntities();
		//double score = aEntry.getScore();
		//ArrayList<String> vbps = aEntry.getRelatedActions();
		//String sseqno = "" + seqno;
		//int digits = sseqno.length();
		//String fills [] = { "", "0000", "000", "00", "0", "" };
		//sseqno = fills[digits] + sseqno;
		ArrayList<RSSEntry> children = aEntry.getChildren();
		String ckeys = "";
		if(children != null && children.size() > 0) {
			ckeys = "\"children\":[";
			for(RSSEntry child:children) {
				//ckeys += child.getBarcode() + ", ";
				String ctitle = child.getTitle();
				ctitle = ctitle.replaceAll("\"", "\\\\\"");
				ctitle = ctitle.replaceAll("\n", "");
				String clink = child.getLink();
				ckeys += "{\"title\":\""  + ctitle + "\", \"link\":\"" + clink + "\"}, ";
			}
			ckeys += "]";
		}

		String esjson =
			"\t{\"category\":\""     + aCategory +
		    "\", \"barcode\":\""     + barcode +
			"\", \"source\":\""      + source +
			"\", \"title\":\""       + title +
			"\", \"link\":\""        + link +
			"\", \"mediaURL\":\""    + mediaURL +
			"\", \"description\":\"" + description + ":" + sentiment +
			"\", \"ago\":\""         + ago +
			//\"meta\":\""        + aKey + ":" + rels + ":" + score + ":" + ckeys +
			"\", "                   + ckeys + "},";

		System.out.println(esjson);
	}

	/*private void printCardXL(int aCount, String aCategory, LinkedHashMap<String,RSSEntry> aMap, String aKey, RSSEntry aEntry) {
		String title = aEntry.getTitle();
		String source = aEntry.getSource();
		String mediaURL = aEntry.getMediaURL();
		boolean isVideo = mediaURL != null && mediaURL.endsWith("mp4");
		String link = aEntry.getLink();
		String description = aEntry.getDescription();
		int dlength = description.length();
		Integer barcode = aEntry.getBarcode();
		//Point point = aEntry.getPoint();
		String ago = aEntry.getReadableDate();
		//double score = entry.getScore();
		boolean isOldNews = ago.contains("week") || ago.contains("month");
		boolean hasPredictions = title.contains("predict") || title.contains("might") ||
			description.contains("predict") || description.contains("might");
		String imagePrefix = "";
		if(aCategory.equals("Videos") == false && mediaURL != null && isVideo == false) {
			imagePrefix = "<img class=\"card-image-top\" style=\"width:100%;padding-bottom:10px;\" src=\"" + mediaURL + "\" alt=\"" + "\"></img>\n";
		}
		System.out.println("<div class=\"card border-top-0 border-left-0 border-right-0 border-3\">" +
			imagePrefix + "  <h4 class=\"card-title\"><a href=\"" + link + "\" target=\"_blank\">" + title + "</a></h4>\n" +
			"<p><span class=\"badge badge-primary\">" + source + "</span>&nbsp;" + "<span class=\"badge ago\">" + ago + "</span></p>\n" +
			"<p class=\"card-text h5\">" + description + "&nbsp;" + "<!--(" + dlength + barcode + "," + kritems + ")-->" + "</p><br/>\n");

		dupes.add(aKey);

		ArrayList<String> kritems = aEntry.getRelatedEntities();
		//System.out.println("  <div class=\"card card-text small border-2 border-left-0 border-right-0 border-bottom-0\">" + kritems + "</div>");
		ArrayList<String> kritems = aEntry.getRelatedItems();
		ArrayList<Double> rscores = aEntry.getRelatedScores();
		int rlimit = kritems.size();
		rlimit = rlimit > 5 ? 5 : rlimit;
		for(int rindex = 0; rindex < rlimit; rindex++) {
			String kritem = kritems.get(rindex);
			Double rscore = rscores.get(rindex);
			String rkey = kritem;
			RSSEntry ritem = (RSSEntry)aMap.get(rkey);
			if(ritem != null) {
				String rtitle = ritem.getTitle();
				String rlink = ritem.getLink();
				System.out.println("  <div class=\"card card-text small border-2 border-left-0 border-right-0 border-bottom-0\"><a href=\"" +
					rlink + "\" target=\"_blank\">" + rtitle + "</a>&nbsp;("+ rscore.intValue() + ")</a></div>");
				dupes.add(rkey);
			}
		}

		System.out.println("</div>\n");
	}

	private void printCardL(int aCount, String aCategory, LinkedHashMap<String,RSSEntry> aMap, String aKey, RSSEntry aEntry) {
		String title = aEntry.getTitle();
		String source = aEntry.getSource();
		String mediaURL = aEntry.getMediaURL();
		boolean isVideo = mediaURL != null && mediaURL.endsWith("mp4");
		String link = aEntry.getLink();
		String description = aEntry.getDescription();
		int dlength = description.length();
		Integer barcode = aEntry.getBarcode();
		//Point point = aEntry.getPoint();
		String ago = aEntry.getReadableDate();
		//double score = entry.getScore();
		boolean isOldNews = ago.contains("week") || ago.contains("month");
		boolean hasPredictions = title.contains("predict") || title.contains("might") ||
			description.contains("predict") || description.contains("might");
		String imagePrefix = "";
		if(aCategory.equals("Videos") == false && mediaURL != null && isVideo == false) {
			imagePrefix = "<img class=\"card-image-top\" style=\"width:100%;padding-bottom:10px;\" src=\"" + mediaURL + "\" alt=\"" + "\"></img>\n";
		}
		System.out.println("<div class=\"card border-top-0 border-left-0 border-right-0 border-3\">" +
			imagePrefix + "  <div class=\"card-text small\"><a href=\"" + link + "\" target=\"_blank\">" + title + "</a></div>");

		dupes.add(aKey);

		System.out.println("</div>\n");
	}

	private void printCardM(int aCount, String aCategory, LinkedHashMap<String,RSSEntry> aMap, String aKey, RSSEntry aEntry) {
		String title = aEntry.getTitle();
		String source = aEntry.getSource();
		String mediaURL = aEntry.getMediaURL();
		boolean isVideo = mediaURL != null && mediaURL.endsWith("mp4");
		String link = aEntry.getLink();
		String description = aEntry.getDescription();
		int dlength = description.length();
		Integer barcode = aEntry.getBarcode();
		//Point point = aEntry.getPoint();
		String ago = aEntry.getReadableDate();
		//double score = entry.getScore();
		boolean isOldNews = ago.contains("week") || ago.contains("month");
		boolean hasPredictions = title.contains("predict") || title.contains("might") ||
			description.contains("predict") || description.contains("might");
		String imagePrefix = "";
		//if(aCategory.equals("Videos") == false && mediaURL != null && isVideo == false) {
		//	imagePrefix = "<img class=\"card-image-top\" style=\"width:100%;padding-bottom:10px;\" src=\"" + mediaURL + "\" alt=\"" + "\"></img>\n";
		//}
		System.out.println("<div class=\"card border-top-0 border-left-0 border-right-0 border-3\">" +
			imagePrefix + "  <h4 class=\"card-title\"><a href=\"" + link + "\" target=\"_blank\">" + title + "</a></h4>\n" +
			"<p><span class=\"badge badge-primary\">" + source + "</span>&nbsp;" + "<span class=\"badge ago\">" + ago + "</span></p>\n" +
			"<p class=\"card-text h5\">" + description + "&nbsp;" + "<!--(" + dlength + barcode + "," + kritems + ")-->" + "</p><br/>\n");

		dupes.add(aKey);

		ArrayList<String> kritems = aEntry.getRelatedEntities();
		//System.out.println("  <div class=\"card card-text small border-2 border-left-0 border-right-0 border-bottom-0\">" + kritems + "</div>");
		ArrayList<String> kritems = aEntry.getRelatedItems();
		ArrayList<Double> rscores = aEntry.getRelatedScores();
		int rlimit = kritems.size();
		rlimit = rlimit > 5 ? 5 : rlimit;
		for(int rindex = 0; rindex < rlimit; rindex++) {
			String kritem = kritems.get(rindex);
			Double rscore = rscores.get(rindex);
			String rkey = kritem;
			RSSEntry ritem = (RSSEntry)aMap.get(rkey);
			if(ritem != null) {
				String rtitle = ritem.getTitle();
				String rlink = ritem.getLink();
				System.out.println("  <div class=\"card card-text small border-2 border-left-0 border-right-0 border-bottom-0\"><a href=\"" +
					rlink + "\" target=\"_blank\">" + rtitle + "</a>&nbsp;<!--("+ rscore.intValue() + ")--></a></div>");
				dupes.add(rkey);
			}
		}

		System.out.println("</div>\n");
	}

	private void printCardS(int aCount, String aCategory, LinkedHashMap<String,RSSEntry> aMap, String aKey, RSSEntry aEntry) {
		String title = aEntry.getTitle();
		String source = aEntry.getSource();
		String mediaURL = aEntry.getMediaURL();
		boolean isVideo = mediaURL != null && mediaURL.endsWith("mp4");
		String link = aEntry.getLink();
		String description = aEntry.getDescription();
		int dlength = description.length();
		Integer barcode = aEntry.getBarcode();
		//Point point = aEntry.getPoint();
		String ago = aEntry.getReadableDate();
		//double score = entry.getScore();
		boolean isOldNews = ago.contains("week") || ago.contains("month");
		boolean hasPredictions = title.contains("predict") || title.contains("might") ||
			description.contains("predict") || description.contains("might");

		System.out.println("  <div class=\"card card-text small border-top-0 border-left-0 border-right-0 border-2\"><a href=\"" +
			link + "\" target=\"_blank\">" + title + "<!--(" + aCount + ")--></a></div>");

		dupes.add(aKey);
	}*/
	private String boostImage(RSSEntry entry) {
		String source = entry.getSource();
		String mediaURL = entry.getMediaURL();
		//if(source.equals("DAILYMAIL") == false) {
		//	return mediaURL;
		//}

		String pageURL = entry.getLink();
		pageURL = pageURL.trim();
		String imageURL = null;
		//Extract twitter:image or og:image from the page
		imageURL = imageURLs.get(pageURL);
		if(imageURL == null) {
			imageCacheMiss++;
			//Curl curl = new Curl(pageURL);
			//String contents = curl.getContent();
			//System.err.println(contents);
			//imageURL = extractImageURL(contents);
			//System.err.println(pageURL + "|" + imageURL);
			//imageURLs.put(pageURL, imageURL);
		} else {
			imageCacheHits++;
		}
		//hits.add(pageURL);

		if(imageURL != null) {
			entry.setMediaType("image");
			entry.setMediaURL(imageURL);
		}
		return imageURL;
	}
	/*private String extractImageURL(String aPageContent) {
		//System.err.println(aPageContent);

		String imageURL = null;
		String ogstartPattern  = "\"og:image\"";
		String twstartPattern1 = "\"twitter:image:src\"";
		String twstartPattern2 = "\"twitter:image\"";
		int ogstartIndex  = aPageContent.indexOf(ogstartPattern);
		int twstartIndex1 = aPageContent.indexOf(twstartPattern1);
		int twstartIndex2 = aPageContent.indexOf(twstartPattern2);
		if(ogstartIndex != -1) {
			ogstartIndex += ogstartPattern.length();
			ogstartPattern = "content=\"";
			ogstartIndex = aPageContent.indexOf(ogstartPattern, ogstartIndex);
			ogstartIndex += ogstartPattern.length();
			String endPattern = "\"";
			int endIndex = aPageContent.indexOf(endPattern, ogstartIndex);
			if(endIndex != -1) {
				imageURL = aPageContent.substring(ogstartIndex, endIndex);
			}
		} else if(twstartIndex1 != -1) {
			twstartIndex1 += twstartPattern1.length();
			twstartPattern1 = "content=\"";
			twstartIndex1 = aPageContent.indexOf(twstartPattern1, twstartIndex1);
			twstartIndex1 += twstartPattern1.length();
			String endPattern = "\"";
			int endIndex = aPageContent.indexOf(endPattern, twstartIndex1);
			if(endIndex != -1) {
				imageURL = aPageContent.substring(twstartIndex1, endIndex);
			}
		} else if(twstartIndex2 != -1) {
			twstartIndex2 += twstartPattern2.length();
			twstartPattern2 = "content=\"";
			twstartIndex2 = aPageContent.indexOf(twstartPattern2, twstartIndex1);
			twstartIndex2 += twstartPattern2.length();
			String endPattern = "\"";
			int endIndex = aPageContent.indexOf(endPattern, twstartIndex2);
			if(endIndex != -1) {
				imageURL = aPageContent.substring(twstartIndex2, endIndex);
			}
		}

		return imageURL;
	}*/
	/*private void printNewsPaperHTML2() {
		//System.out.println(content);
		analyzeStats();

		Set<String> categories = content.keySet();
		int ccount = 0;
  		System.out.println("<div class=\"container-fluid\">");
		for(String category : categories) {
			LinkedHashMap map = content.get(category);
			int size = map.size();

			List<String> titles = new ArrayList<>(map.keySet());
			int tcount = titles.size();
			if(tcount < 50) {
				continue;
			}

			int pcount = 0;
			int columnIndex = 0;
			int columnLimits[] = { 6*2, 7*2, 7*2,};
			String titleTags [] = {"h4", "h5", "h5",};
  			int limit = columnLimits.length;
  			System.out.println("<h3 class=\"border-bottom\">&nbsp;&nbsp;" + category + "&nbsp;(" + size + ")</h3>\n");

			System.out.println("<div class=\"card-columns\" style=\"padding:10px 20px\">");
			for(int rowIndex = 0; rowIndex < limit; rowIndex++) {
				pcount = 0;
				while(columnIndex < tcount) {
					if(pcount >= columnLimits[rowIndex]) {
						break;
					}
					//int toss = (int)((Math.random() * 100) * tcount / 100);
					//int toss = tcount / (int)(20 * 1.25);
					//toss = toss == 0 ? 1 : toss;
					int toss = 1;
					String title = titles.get(columnIndex);
					RSSEntry entry = (RSSEntry)map.get(title);
					//String mediaType = entry.getMediaType();
					String mediaURL = entry.getMediaURL();
					boolean isVideo = mediaURL != null && mediaURL.endsWith("mp4");
					String link = entry.getLink();
					String description = entry.getDescription();
					int dlength = description.length();
					//if(dlength > 1500) {
					//	int eos = description.indexOf(".");
					//	if(eos != -1) {
					//		description = description.substring(0, eos+1);
					//	}
					//}

					String source = entry.getSource();
					String readableDate = entry.getReadableDate();

					String imagePrefix = "";
					if(category.equals("Videos") == false && mediaURL != null && isVideo == false) {
						imagePrefix = "<img class=\"card-image-top\" style=\"width:100%;padding-bottom:10px;\" src=\"" + mediaURL + "\" alt=\"" + title + "\"></img>\n";
					}

					Date then = entry.getDate();
					Date now = new Date();
					if(then == null) {
						then = now;
					}
					Duration duration = Duration.between(now.toInstant(), then.toInstant());
					long ndays = duration.toDays();
					long nmonths= Math.abs(ndays / 30);

					if(/*title.length() > 50 && nmonths < 3 /*&& mediaURL != null && dlength < 1024) {
						System.out.println("<div class=\"card\" style=\"border:none\">" +
							imagePrefix + "  <" + titleTags[rowIndex] + " class=\"card-title\"><a href=\"" + link + "\">" + title + "</a></h4>\n" +
							"<p><span class=\"badge badge-primary\">" + source + "</span>&nbsp;" + "<span class=\"badge ago\">" + readableDate + "</span></p>\n" +
							"<p class=\"card-text\">" + description + "&nbsp;(" + dlength + ")</p>\n" +
							"</div>");
						pcount++;
					}
					columnIndex+=toss;
				}
			}
			System.out.println("</div>");

			ccount++;
		}
		System.out.println("</div>");				
	}*/

	private void printMasonryHTML() {
		//System.out.println(content);
		Set<String> categories = content.keySet();
		int ccount = 0;
		System.out.println("<div class=\"card-columns\" style=\"padding: 10px\">");
		//System.out.println("  <div class=\"row\">");
		for(String category : categories) {
			LinkedHashMap map = content.get(category);
			int size = map.size();
			if(ccount % 2 == 0) {
				System.out.println("    <div class=\"card\" style=\"background-color:#ffffff;border: none;padding:3px;\">");
			} else {
				System.out.println("    <div class=\"card\" style=\"background-color:#f7f7f7;border: none;padding:3px;\">");				
			}
			//System.out.println("      <h5 class=\"border-bottom\">" + category + "&nbsp;<span class=\"badge badge-primary\">" + size + "</span></h5>");
			System.out.println("      <h5 class=\"border-bottom\">" + category + "&nbsp;(" + size + ")</h5>");
			//Set<String> titles = map.keySet();
			List<String> titles = new ArrayList<>(map.keySet());
			int itemCount = 0;
			int tcount = titles.size();
			while(itemCount < tcount) {
				int toss = (int)(Math.random() * 1000) % tcount;
				String title = titles.get(itemCount);
				//System.out.println(title);
				RSSEntry entry = (RSSEntry)map.get(title);
				if(tcount >= 50 && (itemCount >= (tcount / 2 - 1))) {
					break;
				}
				String mediaURL = entry.getMediaURL();
				String source = entry.getSource();
				String imagePrefix = "";
				String alignment = "float:right; border-radius:15px";
				int imageFrequency = tcount > 100 ? 10 : 8;

				if(category.equals("Videos") == false && mediaURL != null && (itemCount % imageFrequency == 0)) {
					//if(source.equals("LATIMES") || source.equals("FOXNEWS") || source.equals("CNN") ||
					//	source.equals("WSJ") || source.equals("VARIETY")) {
					imagePrefix = "<div class=\"p-1\"><img style=\"width:150px; " + alignment + "\" src=\"" + mediaURL + "\"</img></div>";
					//}else {
					//	imagePrefix = "<div class=\"p-1\"><img style=\"" + alignment + "\" src=\"" + mediaURL + "\"</img></div>";
					//}
				}
				Date then = entry.getDate();
				Date now = new Date();
				if(then == null) {
					then = now;
				}
				Duration duration = Duration.between(now.toInstant(), then.toInstant());
				long ndays = duration.toDays();
				long nmonths= Math.abs(ndays / 30);

				if(title.length() > 50 && nmonths < 3) {
					System.out.println("      " + imagePrefix + "<div class=\"border-bottom\"><span class=\"badge badge-primary\">" +
					source + "</span>&nbsp;<a class=\"text-decoration-none\" href=\"" +
					//entry.getLink() + "\">" + entry.getTitle() + "</a>&nbsp;<span class=\"badge badge-warning\">"+ entry.getScore() +"</span></div>");
					entry.getLink() + "\">" + entry.getTitle() + "</a>&nbsp<span class=\"ago\">" + entry.getReadableDate() + "</span></div>");
				}
				itemCount++;
			}
			System.out.println("    </div>");				
			ccount++;
		}
		System.out.println("</div>");				
	}
}
