import java.util.*;
import java.net.*;
import java.awt.Point;
//import com.rometools.rome.feed.synd.*;
//import com.rometools.rome.io.*;

class RSSEntry {
    private String title;
    private String category;
    private String link;
    private String source;
    private String mediaType;
    private String mediaURL;
    private int mediaWidth;
    private int mediaHeight;
    private String description;
    private Date date;
    private String readableDate = "";
    private Double score;
    private Double sentiment;
    private Integer barCode;
    private Point point;
    private ArrayList<String> nouns;
    private ArrayList<String> verbs;
    //private ArrayList<Double> scores;
    private RSSEntry parent;
    private ArrayList<RSSEntry> children;
    //private int nimgs;
    //private int nctnt;
    //private int ndesc;
    //private int nmods;
    //private List mods;
    //private List imgs;
    //private List ctnt;
    //private SyndContent desc;
    //String sources [] = {
    //    "CNN", "NYTIMES", "BBC", "DAILYMAIL", "REUTERS", "FOXNEWS", "LATIMES", "CNBC",
    //    "WSJ", "MARKETWATCH", "SCIAM", "ETONLINE", "EONLINE", "VARIETY", "ESPN", "FOXSPORTS", "CNET", "TOI",
    //};

    RSSEntry() {
        nouns = new ArrayList<String>();
        verbs = new ArrayList<String>();
        //scores = new ArrayList<Double>();
        children = new ArrayList<RSSEntry>();
    }
    /*RSSEntry(SyndEntry asyndEntry, String aSource, String aCategory) {
        title = asyndEntry.getTitle().trim();
        category = aCategory;
        source = aSource;
        link = asyndEntry.getLink().trim();
        //related = new ArrayList<Integer>();
        //nimgs = asyndEntry.getEnclosures().size();
        //nctnt = asyndEntry.getContents().size();
        //ndesc = asyndEntry.getDescription() != null ? 1 : 0;
        //nmods = asyndEntry.getModules().size();
        //mods = asyndEntry.getModules();
        //imgs = asyndEntry.getEnclosures();
        //ctnt = asyndEntry.getContents();
        //desc = asyndEntry.getDescription();

        int start = 0;
        int end = 0;
        String startPatterns [] = {"www.", "rss.", "feeds.", "money."};
        String endPatterns [] = {".co", ".co", ".co", ".co"};
        int limit = startPatterns.length;
        source = "";
        for(int index = 0; index < limit; index++) {
            String startPattern = startPatterns[index];
            String endPattern = endPatterns[index];
            start = link.indexOf(startPattern);
            end = link.indexOf(endPattern, start);
            if(start != -1 && end != -1) {
                start += startPattern.length();
                break;
            }
        }

        source = link.substring(start, end);
        source = source.toUpperCase();
    }*/

    public void setTitle(String aTitle) {
        title = aTitle.trim();
        barCode = new Integer(adler32());
    }
    public void setSource(String aSource) {
        source = aSource;
    }
    public void setCategory(String aCategory) {
        category = aCategory;
    }
    public void setLink(String aLink) {
        //System.out.println(aLink);
        link = aLink.trim();

        /*int limit = sources.length;
        source = "UNKNOWN";
        for(int index = 0; index < limit; index++) {
            String pattern = sources[index].toLowerCase();
            if(link.contains(pattern)) {
                source = pattern.toUpperCase();
                break;
            }
        }*/
    }

    public void setMediaType(String aType) {
        mediaType = aType;
    }
    public void setMediaURL(String aURL) {
        mediaURL = aURL;
    }
    public void setDescription(String aDescription) {
        description = aDescription.trim();
    }
    public void setDate(Date aDate) {
        date = aDate;
    }
    public void setScore(double aScore) {
        score = new Double(aScore);
    }
    public void setSentiment(double aScore) {
        sentiment = new Double(aScore);
    }
    public void setReadableDate(String aReadableDate) {
        readableDate = aReadableDate;
    }
    //public void addRelatedEntry(Integer aRelatedEntry, double aScore) {
    //    related.add(aRelatedEntry);
    //    scores.add(new Double(aScore));
    //}
    public void setRelatedEntities(ArrayList<String> aRelated) {
        nouns = aRelated;
    }
    public void setRelatedActions(ArrayList<String> aRelated) {
        verbs = aRelated;
    }
    public void setParent(RSSEntry aParent) {
        parent = aParent;
    }
    public void addChild(RSSEntry aChild) {
        if(children.contains(aChild) == false) {
            children.add(aChild);
        }
    }

    public String getTitle() {
        return title;
    }
    public String getCategory() {
        return category;
    }
    public String getLink() {
        return link;
    }
    public String getMediaType() {
        return mediaType;
    }
    public String getMediaURL() {
        return mediaURL;
    }
    public String getDescription() {
        return description;
    }
    public String getSource() {
        return source;
    }
    public Date getDate() {
        return date;
    }
    public Double getScore() {
        return score;
    }
    public Double getSentiment() {
        return sentiment;
    }
    public String getReadableDate() {
        return readableDate;
    }
    public Integer getBarcode() {
        return barCode;
    }
    public Point getPoint() {
        return point;
    }
    public ArrayList<String> getRelatedEntities() {
        return nouns;
    }
    public ArrayList<String> getRelatedActions() {
        return verbs;
    }
    public RSSEntry getParent() {
        return parent;
    }
    public ArrayList<RSSEntry> getChildren() {
        return children;
    }
    //public ArrayList<Double> getRelatedScores() {
    //    return scores;
    //}
    //public int getImageCount() {
    //    return nimgs;
    //}
    //public int getDescriptionCount() {
    //    return nimgs;
    //}
    //public int getContentCount() {
    //    return nimgs;
    //}
    //public int getModuleCount() {
    //    return nmods;
    //}
    //public List getModules() {
    //    return mods;
    //}
    //public List getEnclosures() {
    //   return imgs;
    //}
    //public List getContents() {
    //    return ctnt;
    //}
    //public SyndContent getDescription() {
    //    return desc;
    //}
    public String toString() {
        return source + "|" + title + "|" + link + "|" + mediaURL;
    }

    /*private int calculateBarCode() {
        int limit = title.length();
        int code = 0;
        for(int index = 0; index < limit; index++) {
            code ^= title.charAt(index);
        }
        return code;
    }*/
    static final int  MOD_ADLER = 65521;

    private Point adler32pt() {
        int a = 1, b = 0;
        int limit = title.length();
        
        // Process each byte of the data in order
        for (int index = 0; index < limit; ++index) {
            a = (a + title.charAt(index)) % MOD_ADLER;
            b = (b + a) % MOD_ADLER;
        }
        
        point = new Point(a, b);

        return point;
    }    
    private int adler32() {
        Point p = adler32pt();
        
        return (p.y << 16) | p.x;
    }    
}
