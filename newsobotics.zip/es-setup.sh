curl -H 'Content-Type: application/json' -XDELETE 'https://x9lx3yf7sr:h3yas5ptyy@newsobotics-4731548659.us-east-1.bonsaisearch.net:443/news'
curl -H 'Content-Type: application/json' -XPUT 'https://x9lx3yf7sr:h3yas5ptyy@newsobotics-4731548659.us-east-1.bonsaisearch.net:443/news' --data-binary @es-create-index.json
curl -H 'Content-Type: application/x-ndjson' -XPOST 'https://x9lx3yf7sr:h3yas5ptyy@newsobotics-4731548659.us-east-1.bonsaisearch.net:443/news/items/_bulk' --data-binary @news-es.json

