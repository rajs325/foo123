./image-booster.sh

#rm *.rss.txt

javac *.java
#java RSSAggregator rss-feeds.txt CSV > news-es.json
java RSSAggregator rss-feeds.txt CORRELATE HTML > news-scripts.js

#cat news-template-header.html > news.html 
#cat err >> news.html
#cat news-template-footer.html >> news.html

