//package com.devglan;

import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.sentdetect.SentenceDetector;
import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.tokenize.WhitespaceTokenizer;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by only2dhir on 11-07-2017.
 */
public class POSTaggingExample {

    POSTaggerME tagger = null;
    POSModel model = null;
    SentenceModel sentenceModel = null;
    ArrayList<String> taggedWords = null;

    public static void main(String args[]) {
        POSTaggingExample tagging = new POSTaggingExample();
        //ArrayList<String> twords = tagging.tag("Actor and comedian Jerry Stiller dies at 92. Actor and comedian Jerry Stiller has died due to natural causes, his son, actor Ben Stiller said in a tweet. He was 92.");
        ArrayList<String> twords = tagging.tag("U.S. jobless rate will get worse: White House adviser. A senior White House economic adviser on Sunday said the nation's unemployment rate would likely continue to rise, potentially above twenty percent, in the next month after April saw a record spike in joblessness.");
        System.out.println(twords);
    }

    POSTaggingExample() {
        try {
            InputStream modelStream =  getClass().getResourceAsStream("./apache-opennlp-1.9.2/models/en-pos-maxent.bin");
            model = new POSModel(modelStream);
            tagger = new POSTaggerME(model);

            InputStream modelIn = getClass().getResourceAsStream("./apache-opennlp-1.9.2/models/en-sent.bin");
            sentenceModel = new SentenceModel(modelIn);
            modelIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<String> tag(String text){
        taggedWords = new ArrayList<String>();
        try {
            if (model != null) {
                POSTaggerME tagger = new POSTaggerME(model);
                if (tagger != null) {
                    String[] sentences = detectSentences(text);
                    for (String sentence : sentences) {
                        String whitespaceTokenizerLine[] = WhitespaceTokenizer.INSTANCE
                                .tokenize(sentence);
                        String[] tags = tagger.tag(whitespaceTokenizerLine);
                        for (int i = 0; i < whitespaceTokenizerLine.length; i++) {
                            String word = whitespaceTokenizerLine[i].trim();
                            String tag = tags[i].trim();
                            taggedWords.add(tag + "#" + word);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return taggedWords;
    }

    public String[] detectSentences(String paragraph) throws IOException {
        SentenceDetector sentenceDetector = new SentenceDetectorME(sentenceModel);
        String sentences[] = sentenceDetector.sentDetect(paragraph);
        //for (String sent : sentences) {
        //    System.out.println(sent);
        //}
        return sentences;
    }
}