
import java.io.*;
import java.util.*;
import java.net.*;
import javax.net.ssl.*;
import java.security.cert.*;
import java.security.*;


import javax.xml.parsers.*;

import org.xml.sax.*;


public class XMLParserSAX {
    /*static {
        final TrustManager[] trustAllCertificates = new TrustManager[] {
            new X509TrustManager() {
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return null; // Not relevant.
                }
                @Override
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    // Do nothing. Just allow them all.
                }
                @Override
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    // Do nothing. Just allow them all.
                }
            }
        };

        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCertificates, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (GeneralSecurityException e) {
            throw new ExceptionInInitializerError(e);
        }
    }*/

    private ArrayList<RSSEntry> entries;

    public static void main(String[] args) {
        new XMLParserSAX(args);
    }

    XMLParserSAX(String args []) {
        SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
        try {
            String source   = args[0];
            String category = args[1];
            Curl curl = new Curl(new String[] {args[2]});
            System.err.println(args[0] + "|" + args[1] + "|" + args[2]);
            //Curl curl = new Curl(args[2]);
            //URL url = new URL(args[2]);

            //HttpsURLConnection connection = (HttpsURLConnection)url.openConnection();
            //java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
            //System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");

            //BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            BufferedReader br = new BufferedReader(new StringReader(curl.getContent()));
            SAXParser saxParser = saxParserFactory.newSAXParser();
            MySAXHandler handler = new MySAXHandler(source, category);
            saxParser.parse(new InputSource(br), handler);
            entries = handler.getEntries();
            br.close();
        } catch (ParserConfigurationException | SAXException | IOException e) {
            System.err.println(args[0] + "|" + args[1] + "|" + args[2]);
            e.printStackTrace();
        }
    }

    ArrayList<RSSEntry> getEntries() {
        return entries;
    }
}
