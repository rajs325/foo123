source setup.txt
java ImageBooster rss-feeds.txt
cp image-urls-new.txt image-urls.txt
