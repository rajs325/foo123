const app = document.getElementById('root');

const logo = document.createElement('img');
logo.src = 'logo.png';

const body = document.createElement('body');
const cardColumns = document.createElement('div');
cardColumns.setAttribute('class', 'card-columns');
body.appendChild(cardColumns);

app.appendChild(logo);
app.appendChild(body);

//const categories = ['Top Stories', 'U.S.', 'World', 'Politics', 'Sports', 'Technology', 'Health', 'Travel', 'Education', 'Business', 'Entertainment', 'TV', ];

//categories.forEach(category =>{
  var request = new XMLHttpRequest();
  request.withCredentials = true;
  request.open('GET', 'https://x9lx3yf7sr:h3yas5ptyy@newsobotics-4731548659.us-east-1.bonsaisearch.net:443/news/_search?q=Top%20Stories&from=0&size=100', true);
  request.send();
  request.onload = function () {

    var data = JSON.parse(this.response);
    if (request.status >= 200 && request.status < 400) {
      data.forEach(item => {
        var newsItem = item._source;
        const card = document.createElement('div');
        card.setAttribute('class', 'card');

        const h1 = document.createElement('h1');
        h1.textContent = newsItem.title;

        //const p = document.createElement('p');
        //p.textContent = newsItem.descri

        container.appendChild(card);
        card.appendChild(h1);
        //card.appendChild(p);
      });
    } else {
      const errorMessage = document.createElement('marquee');
      errorMessage.textContent = `Gah, it's not working!`;
      app.appendChild(errorMessage);
    }

    // Begin accessing JSON data here
    /*const card = document.createElement('div');
    card.setAttribute('class', 'card');
    card.setAttribute('style', 'background-color:#ffffff;border: none;padding:3px;');

    const h5 = document.createElement('h5');
    h5.setAttribute('class', 'border-bottom');
    h5.textContent = category + '('+ data.hits.total.value + ')';

    card.appendChild(h5);

    if (request.readyState === XMLHttpRequest.DONE && request.status >= 200 && request.status < 400) {
      data = data.hits.hits;
      data.forEach(item => {
        var newsItem = item._source;

        const lineItem = document.createElement('div');
        lineItem.setAttribute('class', 'border-bottom');

        const span = document.createElement('span');
        span.setAttribute('class', 'badge badge-primary');
        span.textContent = newsItem.source;

        const ahref = document.createElement('a');
        ahref.setAttribute('href', newsItem.link);
        ahref.textContent = ' ' + newsItem.title;

        card.appendChild(lineItem);
        card.appendChild(span);
        card.appendChild(ahref);
      });
      cardColumns.appendChild(card);
    } else {
      const errorMessage = document.createElement('marquee');
      errorMessage.textContent = `Gah, it's not working!`;
      app.appendChild(errorMessage);
    }*/
  }

//});


