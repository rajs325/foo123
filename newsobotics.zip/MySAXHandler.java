
import java.util.*;
import java.time.*;
import java.io.*;
import java.text.*;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySAXHandler extends DefaultHandler {
	private static final String CHANNEL       = "channel";
	private static final String ITEM          = "item";
	private static final String TITLE         = "title";
	private static final String DESCRIPTION   = "description";
	private static final String LINK          = "link";
	private static final String IMAGE         = "image";
	private static final String URL           = "url";
	private static final String PUBDATE       = "pubDate";
	private static final String MEDIA_GROUP   = "media:group";
	private static final String MEDIA_CONTENT = "media:content";
	private static final String ENCLOSURE     = "enclosure";

	private boolean hasItem;
	private boolean hasTitle;
	private boolean hasDescription;
	private boolean hasLink;
	private boolean hasURL;
	private boolean hasPubDate;
	private boolean hasMediaGroup;
	private boolean hasMediaContent;
	private boolean hasEnclosure;

	private StringBuilder buffer = null;
	private String source;
	private String category;
	private String mediaType = null;
	private String mediaURL = null;
	private int mediaWidth;
	private int mediaHeight;

	ArrayList<RSSEntry> entries;
	RSSEntry entry;

	MySAXHandler(String aSource, String aCategory) {
		entries = new ArrayList();
		category = aCategory;
		source = aSource;
	}
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		//System.out.println("startElement:"+qName + ":" + attributes);
		if(entry == null) {
			entry = new RSSEntry();
			entry.setSource(source);
			entry.setCategory(category);
		}

		if(ITEM.equals(qName)) {
			hasItem = true;
		}else if(TITLE.equals(qName)) {
			hasTitle = true;
		} else if(DESCRIPTION.equals(qName)){
			hasDescription = true;
		} else if(LINK.equals(qName)) {
			hasLink = true;
		} else if(URL.equals(qName)) {
			hasURL = true;
		} else if(PUBDATE.equals(qName)) {
			hasPubDate = true;
		} else if(MEDIA_GROUP.equals(qName)) {
			hasMediaGroup = true;
		} else if(MEDIA_CONTENT.equals(qName)) {
			hasMediaContent = true;
			mediaType = "";
			mediaURL = "";
			int limit = attributes.getLength();
			for(int index = 0; index < limit; index++) {
				String attrName = attributes.getQName(index);
				if(attrName.equals("type")) {
					mediaType = attributes.getValue(index);
				} else if(attrName.equals("url")) {
					mediaURL = attributes.getValue(index);
				} else if(attrName.equals("width")) {
					String mw = attributes.getValue(index);
					try {
						mediaWidth = Integer.parseInt(mw);
					}catch(Exception e) {
						mediaWidth = 0;
					}
				} else if(attrName.equals("height")) {
					String mh = attributes.getValue(index);
					try {
						mediaHeight = Integer.parseInt(mh);
					}catch(Exception e) {
						mediaHeight = 0;
					}
				}
			}
		} else if(ENCLOSURE.equals(qName)) {
			hasEnclosure = true;
			int limit = attributes.getLength();
			for(int index = 0; index < limit; index++) {
				String attrName = attributes.getQName(index);
				if(attrName.equals("type")) {
					mediaType = attributes.getValue(index);
				} else if(attrName.equals("url")) {
					mediaURL = attributes.getValue(index);
				}
			}
		}

		buffer = new StringBuilder();
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {


		if(CHANNEL.equals(qName)) {
			//System.out.println("MySAXHandler.endElement:" + entries.toString());
		} else if(ITEM.equals(qName)) {
			//System.out.println(entry.toString());
			entries.add(entry);
			entry = null;
		} else if(TITLE.equals(qName)) {
			hasTitle = false;
			//System.out.println("title:"+buffer);
			String title = buffer.toString();
			//title = title.replaceAll("\\.", ";");
			entry.setTitle(title);
		} else if(DESCRIPTION.equals(qName)){
			hasDescription = false;
			//System.out.println("description:"+buffer);
			String text = buffer.toString();
			String imageURL = "";

			//only happens for EONLINE
			String unwantedPattern = "resize/66/66//";
			if(text.contains(unwantedPattern) == true) {
				text = text.replaceAll(unwantedPattern, "");
				String startPattern = "<img src=";
				String endPattern = "/>";
				String midPattern = " height=";
				int startIndex = text.indexOf(startPattern) + startPattern.length();
				int endIndex = text.indexOf(endPattern, startIndex) + endPattern.length();
				int midIndex = text.indexOf(midPattern, startIndex);

				//System.out.println(startIndex + "," + midIndex);
				String mediaURL = text.substring(startIndex+1, midIndex-1);
				mediaURL = mediaURL.trim();
				mediaURL = mediaURL.replaceAll("\"", "");

				entry.setMediaType("image");
				entry.setMediaURL(mediaURL);
				text = text.substring(endIndex);
				text = text.replaceAll("<br clear=\"all\" />", "");
				text = text.replaceAll("\r\n", "\n");
			}

			//only happens for CNN
			unwantedPattern = "<div class=\"feedflare\">";
			if(text.contains(unwantedPattern) == true) {
				int startIndex = text.indexOf(unwantedPattern);
				text = text.substring(0, startIndex);
			}

			//only happens for FOXNEWS
			unwantedPattern = "<img src=\"http://feeds.feedburner.com/~r/foxnews/";
			if(text.contains(unwantedPattern) == true) {
				int startIndex = text.indexOf(unwantedPattern);
				text = text.substring(0, startIndex);
			}

			//only happens for LATIMES
			unwantedPattern = "<p>";
			if(text.contains(unwantedPattern) == true) {
				text = text.replaceAll(unwantedPattern, "");
			}
			unwantedPattern = "</p>";
			if(text.contains(unwantedPattern) == true) {
				text = text.replaceAll(unwantedPattern, "");
			}

			//only happens for THESUN
			if(source.equals("THESUN")) {
				String startPattern = "<b>";
				String endPattern = ".";
				int startIndex = text.indexOf(startPattern);
				int endIndex = text.indexOf(endPattern, startIndex);
				if(startIndex != -1 && endIndex != -1) {
					text = text.substring(startIndex, endIndex + 1);
				}
				startPattern = "<img src";
				endPattern = "\">";
				startIndex = text.indexOf(startPattern);
				endIndex = text.indexOf(endPattern, startIndex);
				if(startIndex != -1 && endIndex != -1) {
					endIndex += endPattern.length();
					text = text.substring(endIndex);
				}
				endPattern = ".";
				endIndex = text.indexOf(endPattern);
				if(endIndex != -1) {
					endIndex += endPattern.length();
					text = text.substring(0, endIndex);
				}
			}

			//only happens for GUARDIAN
			if(source.equals("GUARDIAN")) {
				String endPattern = "<ul>";
				int endIndex = text.indexOf(endPattern);
				if(endIndex != -1) {
					text = text.substring(0, endIndex);
				}
				endPattern = ".";
				endIndex = text.indexOf(endPattern);
				if(endIndex != -1) {
					text = text.substring(0, endIndex);
				}
				endPattern = "?";
				endIndex = text.indexOf(endPattern);
				if(endIndex != -1) {
					text = text.substring(0, endIndex);
				}
				endPattern = "<a";
				endIndex = text.indexOf(endPattern);
				if(endIndex != -1) {
					text = text.substring(0, endIndex);
				}
				text += "...";
				text = text.replaceAll("<strong>", "");
				text = text.replaceAll("</strong>", "");
				text = text.replaceAll("<em>", "");
				text = text.replaceAll("<br>", "");
			}

			entry.setDescription(text);
		} else if(LINK.equals(qName)) {
			hasLink = false;
			//System.out.println("link:"+buffer);
			String url = buffer.toString();
			url = url.trim();
			entry.setLink(url);
		} else if(URL.equals(qName)) {
			hasURL = false;
			//System.out.println("URL:"+buffer);
			//entry.setTitle(buffer);
		} else if(PUBDATE.equals(qName)) {
			hasPubDate = false;
			String value = buffer.toString();
			//System.err.println(source+"***"+value);
			
			String dfpattern1 = "EEE, dd MMM yyyy HH:mm:ss Z";
			String dfpattern2 = "yyyy-MM-dd HH:mm:ss Z";
			String dfpattern3 = "EEE, dd MMM yyyy HH:mm Z";
			Date then = null;
			try {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dfpattern1);
				then = simpleDateFormat.parse(value);
			}catch(ParseException e1) {
				try {
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dfpattern2);
					then = simpleDateFormat.parse(value);
				}catch(ParseException e2) {
					try {
						SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dfpattern3);
						then = simpleDateFormat.parse(value);
					}catch(ParseException e3) {
						e3.printStackTrace();
					}
				}
			}finally {
			}

			//Date then = new Date(value);
			Date now = new Date();
			Duration duration = Duration.between(now.toInstant(), then.toInstant());
			entry.setDate(then);

			long ndays = duration.toDays();
			long nmonths= ndays / 30;
			long nweeks = ndays / 7;
			long nhours = duration.toHours();
			long nmins = duration.toMinutes();

			String readableDate = "";
			if(nmonths < 0) {
				nmonths = Math.abs(nmonths);
				readableDate = nmonths + (nmonths == 1 ? " month ago" : " months ago");
			} else if(nweeks < 0) {
				nweeks = Math.abs(nweeks);
				readableDate = nweeks + (nweeks == 1 ? " week ago" : " weeks ago");
			} else if(ndays < 0) {
				ndays = Math.abs(ndays);
				readableDate = ndays + (ndays == 1 ? " day ago" : " days ago");
			} else if(nhours < 0) {
				nhours = Math.abs(nhours);
				readableDate = nhours + (nhours == 1 ? " hour ago" : " hours ago");
			} else if(nmins < 0) {
				nmins = Math.abs(nmins);
				readableDate = nmins + (nmins == 1 ? " minute ago" : " minutes ago");
			}

			entry.setReadableDate(readableDate);
			//System.out.println("pubdate:"+buffer);
		} else if(MEDIA_GROUP.equals(qName)) {
			hasMediaGroup = false;
			//entry.setTitle(buffer);
			//System.out.println("MEDIA_GROUP:"+buffer);
		} else if(MEDIA_CONTENT.equals(qName)) {
			hasMediaContent = false;
			if(mediaURL.contains("nyt.com/images") && mediaURL.contains("-moth")) {
				mediaURL = mediaURL.replaceAll("-moth", "-facebookJumbo");
				mediaURL = mediaURL.replaceAll("v3", "v2");
			}else if(mediaURL.contains("huffingtonpost.com") && mediaURL.contains("ops=224_126")) {
				mediaURL = mediaURL.replaceAll("ops=224_126", "ops=1778_1000");
			}
			if(entry.getMediaURL() == null || source.equals("GUARDIAN")) {
				entry.setMediaType(mediaType);
				entry.setMediaURL(mediaURL);
			}
			//System.out.println("MEDIA_CONTENT:"+buffer);
		} else if(ENCLOSURE.equals(qName)) {
			hasEnclosure = false;
			if(mediaURL.contains("nyt.com/images") && mediaURL.contains("-moth")) {
				mediaURL = mediaURL.replaceAll("-moth", "-facebookJumbo");
				mediaURL = mediaURL.replaceAll("v3", "v2");
			}else if(mediaURL.contains("huffingtonpost.com") && mediaURL.contains("ops=224_126")) {
				mediaURL = mediaURL.replaceAll("ops=224_126", "ops=1778_1000");
			}
			if(entry.getMediaURL() == null || source.equals("GUARDIAN")) {
				entry.setMediaType(mediaType);
				entry.setMediaURL(mediaURL);
			}
		}
		//System.out.println(qName);
	}


	@Override
	public void characters(char ch[], int start, int length) throws SAXException {
		buffer.append(new String(ch, start, length));
	}

	public ArrayList<RSSEntry> getEntries() {
		return entries;
	}
}