import java.util.*;
import java.time.*;

class Tester {
	POSTaggingExample tagger = new POSTaggingExample();

	public static void main(String args[]) {
		Tester t = new Tester();
		//t.layoutTest()
		//t.entrySourceTest();
		//t.readableDateTest();
		//t.truncateDescriptionTest();
		//t.eonlineImageLinkFromDescriptionTest();
		//t.exactMatchTest();
		//t.latimesDescriptionTest();
		//t.thesunDescriptionTest();
		//t.readPageContentsTest();
		//t.quotesRemovalTest();
		//t.removePunctuationsTest();
		//t.nounTest();
		t.calcuateTextSimilarityTest();
		//t.bagContextTest();
	}
	void layoutTest() {
		System.out.println("<div class=\"container-fluid\">");
		for(int first = 0; first < 21; first++) {
			if(first % 3 == 0) {
				System.out.println("  <div class=\"row\">");
			}
			if(first % 2 == 0) {
				System.out.println("    <div class=\"col-sm-4\" style=\"background-color:lavender;\">");
			} else {
				System.out.println("    <div class=\"col-sm-4\" style=\"background-color:lavenderblush;\">");				
			}

			System.out.println("    </div>");
			if(first % 3 == 2) {
				System.out.println("  </div>");
			}
		}
		System.out.println("</div>");
	}
	void entrySourceTest() {
		//String link = "https://www.latimes.com/travel/story/2020-03-28/acts-kindness-share-story-coronavirus";
		//String link = "https://www.dailymail.co.uk/news/article-8200573/Air-kissing-Parakeets-one-peck-beak-mid-air.html?ns_mchannel=rss&ns_campaign=1490&ito=1490";
		//String link = "http://rss.cnn.com/~r/rss/cnn_us/~3/yK9rZ7t0bnQ/article_cd636686-80e8-11ea-9ea6-eba190754ed7.html";
		String link = "http://feeds.reuters.com/~r/reuters/technologyNews/~3/GjTVkk_Urns/hacking-against-corporations-surges-as-workers-take-computers-home-idUSKBN21Z0Y6";



        int start = 0;
        int end = 0;
        String startPatterns [] = {"www.", "rss.", "feeds."};
        String endPatterns [] = {".co", ".co", ".co"};
        int limit = startPatterns.length;
        String source = "";
        for(int index = 0; index < limit; index++) {
            String startPattern = startPatterns[index];
            String endPattern = endPatterns[index];
            System.out.println(startPattern + "," + endPattern);
            start = link.indexOf(startPattern);
            end = link.indexOf(endPattern, start);
            System.out.println(start + "," + end);
            if(start != -1 && end != -1) {
                start += startPattern.length();
                break;
            }
        }

        source = link.substring(start, end);
        source = source.toUpperCase();
        System.out.println(source);
    }
	void readableDateTest() {
		Date then = new Date("Wed Mar 18 13:19:14 PDT 2020");
		Date now = new Date();
		Duration duration = Duration.between(now.toInstant(), then.toInstant());
		System.out.println(duration);
		//entry.setDate(then);

		long ndays = duration.toDays();
		System.out.println("days:"+ndays);
		String readableDate = "";
		if(ndays >= 0) {
			long nhours = duration.toHours();
			System.out.println("hours:"+nhours);
			if(nhours >= 0) {
				long nmins = duration.toMinutes();
				System.out.println("minutes:"+nmins);
				if(nmins < 0) {
					readableDate = Math.abs(nmins) + " minutes ago";					
				}
			} else {
				readableDate = Math.abs(nhours) + " hours ago";					
			}
		} else {
			readableDate = Math.abs(ndays) + " days ago";
		}
		System.out.println(readableDate);
	}

	void truncateDescriptionTest() {
		String description = "Planet of the Humans, which takes aim at the green movement, is ‘full of misinformation’, says one online library</p><p>A new Michael Moore-produced documentary that takes aim at the supposed hypocrisy of the green movement is “dangerous, misleading and destructive” and should be removed from public viewing, according to an assortment of climate scientists and environmental campaigners.</p><p>The film, <a href=\"https://www.theguardian.com/film/2020/apr/22/planet-of-the-humans-review-environment-michael-moore-jeff-gibbs\">Planet of the Humans</a>, was released on the eve of Earth Day last week by its producer, Michael Moore, the baseball cap-wearing documentarian known for Fahrenheit 9/11 and <a href=\"https://www.theguardian.com/culture/2002/nov/15/artsfeatures4\">Bowling for Columbine</a>. Describing itself as a “full-frontal assault on our sacred cows”, the film argues that electric cars and solar energy are unreliable and rely upon fossil fuels to function. It also attacks figures including Al Gore for bolstering corporations that push flawed technologies over real solutions to the climate crisis.</p> <a href=\"https://www.theguardian.com/environment/2020/apr/28/climate-dangerous-documentary-planet-of-the-humans-michael-moore-taken-down\">Continue reading...";
		int dlength = description.length();
		if(dlength > 500) {
			int eos = description.indexOf(".");
			if(eos != -1) {
				description = description.substring(0, eos+1);
			}
		}
		System.out.println(description);		
	}

			//only happens for eonline
	void eonlineImageLinkFromDescriptionTest() {
		String text = "<img src=\"https://images.eonline.com/resize/66/66//eol_images/Entire_Site/202036//rs_600x600-200406130831-600-peter-weber-kelley-flanagan-bachelor.jpg\" height=\"66\" width=\"66\" border=\"0\" alt=\"Peter Weber, Kelley Flanagan\" align=\"left\" hspace=\"5\" />Peter Weber and Kelley Flanagan are finally a couple. After quarantining together for nearly a month, the former Bachelor and practicing lawyer are \"officially dating,\" a source...<br clear=\"all\" />";
		String unwantedPattern = "resize/66/66//";
		if(text.contains(unwantedPattern) == true) {
			text = text.replaceAll(unwantedPattern, "");
			String startPattern = "<img src=";
			String endPattern = "/>";
			String midPattern = " height=";
			int startIndex = text.indexOf(startPattern) + startPattern.length();
			int endIndex = text.indexOf(endPattern, startIndex) + endPattern.length();
			int midIndex = text.indexOf(midPattern, startIndex);

			System.out.println(text.substring(startIndex, midIndex));
			text = text.substring(endIndex);
		}

		System.out.println(text);
	}
	void latimesDescriptionTest() {
		String text = "<p>Too many 'shiny objects': Why it's risky to promise a coronavirus vaccine and cure</p>";
		//String text = "<p>";
		String unwantedPattern = "<p>";
		if(text.contains(unwantedPattern)) {
			text = text.replaceAll(unwantedPattern, "");
		}
		System.out.println(text);
	}
	void thesunDescriptionTest() {
		String text = "<img src=\"https://www.thesundaily.my/binrepository/400x225/0c0/400d225/none/11808/VOCY/kindergarten_1134251_20200504215724.jpg\"><b>KUALA LUMPUR: </b>Although nurseries and child care centres have been allowed to reopen following the Conditional Movement Control Order (CMCO) today, most operators say they are only ready to start operations on a small scale starting next week.A <i>Bernama</i> survey in the Pandan Indah, Setapak, Cheras and Ampang areas found that most child care entrepreneurs did not want to rush and needed time to make specific preparations according to the guidelines set by the National Security Council (MKN) first.Instead, most of them are busily engaged in thoroughly cleaning and sanitising their premises.Taska Nur Bistari owner Siti Salwani Suhaimi said they give priority to parents who have to work during the CMCO especially children of frontline workers.“Currently we are in the process of cleaning and disinfecting the premises and nursery equipment. In addition, to reconfiguring the nursery and putting up signs and box markings on the floor to maintain social spacing of children.“To comply with the social distancing, nurseries can only receive no more than 15 children per day and it depends on the application by parents who want to send their children,” she told Bernama.Siti Salwani said she believes in the current situation nursery services should be a social support and not be motivated by business and profit alone.“That’s why I don’t care even if the children being cared for are less than the usual 40 children per day. I do not want over crowding and we understand that everyone is also worried about the spread of COVID-19,” she said.According to the owner of Taska Didik Khalifah, Nurul Hannah Wahab, the nursery will take in a small number of children starting from May 13 besides shortening the operating hours from 7 am to 6 pm instead of the usual 8 pm.“We are operating to facilitate parents who need child-care services due to their work demands. Parents who can take leave or work from home are not encouraged to send their children,” she said.“An early census is also being conducted to determine the number of children who will be coming to facilitate the management of the nursery for social spacing. If there are children of frontline workers we will take note of their records and separate them to do activities planned upstairs,“ he added. .According to the NSC, the nursery operator, teachers as well as other staff members and children must be screened before/ during/ and after operating hours for COVID-19, while the premises must be cleaned and disinfected.In addition, teachers and staff must be trained on hygiene practices and safety measures. — <i>Bernama</i>&nbsp;</p>";
		String unwantedPattern = "https://www.thesundaily.my/";
		if(text.contains(unwantedPattern)) {
			String startPattern = "<b>";
			String endPattern = ".";
			int startIndex = text.indexOf(startPattern);
			int endIndex = text.indexOf(endPattern, startIndex);
			System.out.println(startIndex + "," + endIndex);
			if(startIndex != -1 && endIndex != -1) {
				text = text.substring(startIndex, endIndex);
			}
		}
		System.out.println(text);
	}
	void exactMatchTest() {
		String title1 = "Joe Biden denies sexually assaulting staff assistant Tara Reade";
		String title2 = "Joe Biden Denies Tara Reade's Sexual Assault Allegation";
		String title3 = "Biden denies sexual assault allegation: 'This never happened'";
		String title4 = "U.S. economy, in clear sign of recession, shrinks 4.8% in first quarter due to coronavirus";
		String title5 = "University of Delaware says it still has no plans to release Biden's Senate papers, as pressure mounts";

		System.out.println(hashCodex(title1));
		System.out.println(hashCodex(title2));
		System.out.println(hashCodex(title3));
		System.out.println(hashCodex(title4));
		System.out.println(hashCodex(title5));
		System.out.println(title1.hashCode());
		System.out.println(title2.hashCode());
		System.out.println(title3.hashCode());
		System.out.println(title4.hashCode());
		System.out.println(title5.hashCode());
	}

	void readPageContentsTest() {
		String url = "https://www.dailymail.co.uk/news/article-8288995/Nicola-Sturgeon-breaks-ranks-unveiling-Scottish-coronavirus-plan.html?ns_mchannel=rss&ito=1490&ns_campaign=1490";
		Curl curl = new Curl(new String[] {url});
		String contents = curl.getContent();
		System.out.println(contents);
		String imageURL = extractImageURL(contents);
		System.out.println(imageURL);
	}

	private String extractImageURL(String aPageContent) {
		//System.err.println(aPageContent);
		String imageURL = null;
		String ogstartPattern  = "\"og:image\"";
		String twstartPattern1 = "\"twitter:image:src\"";
		String twstartPattern2 = "\"twitter:image\"";
		int ogstartIndex  = aPageContent.indexOf(ogstartPattern);
		int twstartIndex1 = aPageContent.indexOf(twstartPattern1);
		int twstartIndex2 = aPageContent.indexOf(twstartPattern2);
		if(ogstartIndex != -1) {
			ogstartIndex += ogstartPattern.length();
			ogstartPattern = "content=\"";
			ogstartIndex = aPageContent.indexOf(ogstartPattern, ogstartIndex);
			ogstartIndex += ogstartPattern.length();
			String endPattern = "\"";
			int endIndex = aPageContent.indexOf(endPattern, ogstartIndex);
			if(endIndex != -1) {
				imageURL = aPageContent.substring(ogstartIndex, endIndex);
			}
		} else if(twstartIndex1 != -1) {
			twstartIndex1 += twstartPattern1.length();
			twstartPattern1 = "content=\"";
			twstartIndex1 = aPageContent.indexOf(twstartPattern1, twstartIndex1);
			twstartIndex1 += twstartPattern1.length();
			String endPattern = "\"";
			int endIndex = aPageContent.indexOf(endPattern, twstartIndex1);
			if(endIndex != -1) {
				imageURL = aPageContent.substring(twstartIndex1, endIndex);
			}
		} else if(twstartIndex2 != -1) {
			twstartIndex2 += twstartPattern2.length();
			twstartPattern2 = "content=\"";
			twstartIndex2 = aPageContent.indexOf(twstartPattern2, twstartIndex1);
			twstartIndex2 += twstartPattern2.length();
			String endPattern = "\"";
			int endIndex = aPageContent.indexOf(endPattern, twstartIndex2);
			if(endIndex != -1) {
				imageURL = aPageContent.substring(twstartIndex2, endIndex);
			}
		}

		return imageURL;
	}

    HashMap<HashSet<String>, ArrayList<Integer>> bagContexts;

	void bagContextTest() {
		bagContexts = new HashMap<HashSet<String>, ArrayList<Integer>>();

		HashSet<String> key = new HashSet<String>();
		key.add("nnp#study");
		key.add("nnp#calgary");
		key.add("nnp#university");

		ArrayList<Integer> value = new ArrayList<Integer>();
		value.add(new Integer(+1234));
		value.add(new Integer(+2345));
		value.add(new Integer(+3456));
		value.add(new Integer(-1234));
		value.add(new Integer(-2345));
		value.add(new Integer(-3456));

		bagContexts.put(key, value);

        Iterator<HashSet<String>> ckeys = (Iterator<HashSet<String>>)bagContexts.keySet().iterator();
        while(ckeys.hasNext()) { 
        	HashSet<String> ckey = ckeys.next();
            ArrayList<Integer> cvalue = (ArrayList<Integer>)bagContexts.get(ckey); 
            if(cvalue.size() > 0) {
                System.out.println(ckey + "=\n\t" + cvalue);
            }
        } 
	}

	void calcuateTextSimilarityTest() {
		//North Korean media reports Kim Jong Un made first public appearance in weeks
		//Kim Jong Un reportedly seen in public
		//Kim Jong-un appears in public, North Korean state media report
		//North Korean state media reports Kim Jong Un has resumed public activity
		//North Korean State Media Claims Kim Jong Un Has Made A Public Appearance
		/*String text1 = "Little Richard, flamboyant rocker who fused gospel fervor and R&B sexuality, dies at 87 "; //"Little Richard, the flamboyant, piano-pounding showman who injected sheer abandon into rock 'n' roll in its early days, died Saturday. He was 87.";
		String text2 = "Little Richard: an ultra-sexual force of anti-nature"; //"He gave McCartney tips on how to scream in tune and paved the way for everyone from Otis Redding to Prince...";
		String text3 = "Little Richard, rock'n'roll pioneer, dies aged 87"; //"His 1955 song Tutti Frutti, with the lyric ‘awopbopaloobop alopbamboom’, and a series of follow-up records helped establish the genre and influence a multitude of other musicians...";
		String text4 = "Actor and comedian Jerry Stiller has died of natural causes, Ben Stiller says"; //"Actor and comedian Jerry Stiller has died due to natural causes, his son, actor Ben Stiller said in a tweet. He was 92.";
		String text5 = "Ariana Grande Self-Isolates With New Beau Dalton Gomez In 'Stuck With You' Video"; //"The pop superstar's duet with Justin Bieber also confirmed her much-rumored relationship with Gomez, a real estate agent.";
		String text6 = "Jo Malone admits having a strict routine is 'vital' to control her anxiety"; //"The British perfumer and mother-of-one, who is currently isolating at her Chelsea flat with her husband and son, told The Sunday Times Home lockdown has brought her family closer together.";
		String text7 = "Ariana Grande and Justin Bieber are 'Stuck With U' for coronavirus relief"; //"Pop stars Ariana Grande and Justin Bieber will release a new song, \"Stuck With U,\" next week in support of front-line heroes of the coronavirus crisis.";
		String text8 = "Actor and comedian Jerry Stiller has died of natural causes, Ben Stiller says";
		String text9 = "Jerry Stiller: Seinfeld star and father of actor Ben dies aged 92";
		String text10 = "Celebrities react to Jerry Stiller's death at age 92: 'A beloved person in comedy'";
		String text11 = "Jerry Stiller's 'Seinfeld,’ 'King of Queens' co-stars react to his death: 'You will be so very missed'";
		String text12 = "The Story Behind Jerry Stiller's 'Seinfeld' Blooper Will Have You Breaking Too";
		String text13 = "Jerry Stiller’s best movie and TV moments: ‘Ed Sullivan’ to ‘Seinfeld’";
		String text14 = "Harry Dunn crash: Suspect Anne Sacoolas 'wanted internationally'";
		String text15 = "Prince Harry sends support message to Invictus Games participants";
		String text16 = "Prince Harry and Meghan Markle put screens up at $18m mansion";

		double score = 0;
		score = calculateSimilarity(text1, text2);
		score = calculateSimilarity(text2, text3);
		score = calculateSimilarity(text3, text1);
		score = calculateSimilarity(text3, text4);
		score = calculateSimilarity(text3, text5);
		score = calculateSimilarity(text3, text6);

		score = calculateSimilarity(text5, text7);

		score = calculateSimilarity(text9, text10);
		score = calculateSimilarity(text9, text11);
		score = calculateSimilarity(text9, text12);
		score = calculateSimilarity(text9, text13);

		score = calculateSimilarity(text14, text15);
		score = calculateSimilarity(text14, text16);*/
		String text1 = "Despite Global Censure, China's Parliament Approves Hong Kong National Security Law";
		String text2 = "Hong Kong Bans Tiananmen Vigil for 1st Time, in New Challenge to Protests";
		String text3 = "China Responds with Restraint to Trump's Move to End Hong Kong's 'Special Status'";
		String text4 = "With Hong Kong's Tiananmen Square Vigil Canceled, 'The Fire Is Flickering'";
		ArrayList<String> e1 = getEntities(text1);
		ArrayList<String> e2 = getEntities(text3);
		double score = calculateSimilarity(e1, e2);
		System.out.println(e1 + "\n" + e2 + "\n" + score);
	}

    private double calculateSimilarity(ArrayList<String> aTerms1, ArrayList<String> aTerms2) {
        int nterms1 = aTerms1.size();
        if(nterms1 == 0) {
            return 0;
        }

        int nterms2 = aTerms2.size();
        if(nterms2 == 0) {
            return 0;
        }
        int nterms = (nterms1 + nterms2) / 2;

        int hits = 0;
        int freq = 0;
        //List<String> keys = new ArrayList<>(entityFrequency.keySet());
        //int maxTerms = keys.size();

        for(String first:aTerms1) {
            for(String second:aTerms2) {
                if(first.equals(second) || first.equals(second + "s") || (first + "s").equals(second)) {
                    hits++;
                    //Integer frequency = entityFrequency.get(first);
                    //if(frequency != null) {
                    //    freq += frequency.intValue();
                    //}
                }
            }
        }
        //hits = hits * 100 / maxTerms;
        //hits += 20;
        double score = (hits * 75 / nterms) /*+ (freq * hits * 25 / maxTerms)*/;
        //double score = hits * 100 / (nterms1 + nterms2);
        //double score = hits * (nterms1 + nterms2) * 100 / maxTerms;
        //if(score > 40) {
        //    System.err.println("maxTerms:" + maxTerms + ", freq:" + freq + ", hits:" + hits +
        //        ", n1:" + nterms1 + ", n2:" + nterms2 + ", score:" + score);
        //}
        return score;
    }

    private double calculateSimilarity(String aText1, String aText2) {
        aText1 = removePunctuations(aText1);
        aText2 = removePunctuations(aText2);
        ArrayList<String> ttext1 = tagger.tag(aText1);
        ArrayList<String> ttext2 = tagger.tag(aText2);
        ArrayList<String> bag1 = new ArrayList<String>();
        ArrayList<String> bag2 = new ArrayList<String>();
        HashMap<String,String> seq1 = new HashMap<String,String>();
        HashMap<String,String> seq2 = new HashMap<String,String>();

        //System.out.println(ttext1);
        //System.out.println(ttext2);
        int nouns1 = 0;
        int nouns2 = 0;
        String pword = "";
        for(String word:ttext1) {
            if(word.startsWith("NNP") /*|| word.startsWith("NN")*/) {
                word = word.toLowerCase();
                word = removePunctuations(word);
                bag1.add(word);
                //System.out.println(word);
	            //if(pword.isEmpty() == false) {
	            //    seq1.put(pword, word);
	            //}
            	//pword = word;
                nouns1++;
            }
        }

        pword = "";
        //System.out.println("***");
        for(String word:ttext2) {
            if(word.startsWith("NNP") /*|| word.startsWith("NN")*/) {
                word = word.toLowerCase();
                word = removePunctuations(word);
                bag2.add(word);
                //System.out.println(word);
	            //if(pword.isEmpty() == false) {
	            //    seq2.put(pword, word);
	            //}
            	//pword = word;
                nouns2++;
            }
        }

        int hits = 0;

        //Iterator<String> itbag1 = (Iterator<String>)bag1.iterator();
        //Iterator<String> itbag2 = (Iterator<String>)bag2.iterator();
        System.out.println(bag1);
        System.out.println(bag2);

        pword = "";
        String singular = "";
        for(String word:bag1) {
            if(word.endsWith("s")) {
            	singular = word.substring(0, word.length() - 1);
            	singular = singular.replaceAll("nnps", "nnp");
            } else {
            	singular = "";
            }
            //String next = (String)seq2.get(pword);
            //if(next == null) {
            //    next = "";
            //}
            //System.out.println(word);
            if(/*next.startsWith(word) ||*/ bag2.contains(word) || bag2.contains(singular)) {
                System.out.println("*"+word+","+singular);
                hits++;
            }

        }

        pword = "";
        singular = "";
        for(String word:bag2) {
            //String word = (String)spout.next();
            if(word.endsWith("s")) {
            	singular = word.substring(0, word.length() - 1);
            	singular = singular.replaceAll("nnps", "nnp");
            } else {
            	singular = "";
            }
            //String next = (String)seq1.get(pword);
            //if(next == null) {
            //    next = "";
            //}
            //System.out.println(word);
            if(/*next.startsWith(word) ||*/ bag1.contains(word) || bag1.contains(singular)) {
                System.out.println("*"+word+","+singular);
                hits++;
            }
        }

        double score = (double)hits * 100 / (nouns1 + nouns2);
        //if(score >= 25 && score < 36) {
        //    score *= 2.5;
        //}

        ttext1 = null;
        ttext2 = null;
        bag1 = null;
        bag2 = null;

        System.out.println(aText1);
        System.out.println(aText2);
        System.out.println(score+"\n");

        return score;
    }

    private double calculateSimilarity2(String aText1, String aText2) {

        String words1[] = aText1.split(" ");
        String words2[] = aText2.split(" ");
        
        if(words1.length == 0 || words2.length == 0) {
            return 0;
        }

        //aText1 = removePunctuations(aText1);
        //aText2 = removePunctuations(aText2);

        HashSet bag1 = new HashSet<String>();
        HashSet bag2 = new HashSet<String>();
        HashMap seq1 = new HashMap<String,String>();
        HashMap seq2 = new HashMap<String,String>();
        ArrayList sentance1 = new ArrayList<String>();
        ArrayList sentance2 = new ArrayList<String>();
        HashSet nouns1 = new HashSet<String>();
        HashSet nouns2 = new HashSet<String>();

        String pword = "";
        int nwords = words1.length;
        int index = 0;
        int top20 = (int)((double)10 * nwords / 100);

        for(String word : words1) {
            word = word.toLowerCase();
            word = removePunctuations(word);
            bag1.add(word);
            sentance1.add(word);
            //if(index <= top20) {
            //    nouns1.add(word);
            //}
            if(pword.isEmpty() == false) {
                seq1.put(pword, word);
            }
            pword = word;
            //index++;
        }

        pword = "";
        nwords = words2.length;
        index = 0;
        top20 = (int)((double)10 * nwords / 100);
        for(String word : words2) {
            word = word.toLowerCase();
            word = removePunctuations(word);
            bag2.add(word);
            sentance2.add(word);
            //if(index <= top20) {
            //    nouns2.add(word);
            //}
            if(pword.isEmpty() == false) {
                seq2.put(pword, word);
            }
            pword = word;
            //index++;
        }

        int hits = 0;
        int kghits = 0;
        pword = "";
        for(String word : words1) {
            word = word.toLowerCase();
            String next = (String)seq2.get(pword);
            if(next == null) {
                next = "";
            }
            if(next.startsWith(word) || bag2.contains(word)) {
                hits++;
                //if(kgraph.get(pword + "-" + word) != null || kgraph.get(word) != null) {
                //    kghits ++;
                //}
            }
            pword = word;
        }

        pword = "";
        for(String word : words2) {
            word = word.toLowerCase();
            String next = (String)seq1.get(pword);
            if(next == null) {
                next = "";
            }
            if(next.startsWith(word) || bag1.contains(word)) {
                hits++;
                //if(kgraph.get(pword + "-" + word) != null || kgraph.get(word) != null) {
                //    kghits ++;
                //}
            }
            pword = word;
        }

        double score = (double)hits * 100 / (words1.length + words2.length);
        return score;
    }
    private ArrayList<String> getEntities(String aText) {
        aText = removePunctuations(aText);

        ArrayList<String> ttext = tagger.tag(aText);
        ArrayList<String> nnps = new ArrayList<String>();

        for(String word:ttext) {
            if(word.startsWith("NNP") /*|| word.startsWith("VB")*/) {
            //if(word.startsWith("IN") == false) {
                word = word.toLowerCase();
                word = removePunctuations(word);
                if(word.contains("nnps") && word.endsWith("s")) {
                    word = word.replaceAll("nnps", "nnp");
                    word = word.substring(0, word.length() - 1);
                }
                if(nnps.contains(word) == false && word.contains("<") == false) {
                    nnps.add(word);
                }
            }
        }

        return nnps;
    }

    private ArrayList<String> getActions(String aText) {
        aText = removePunctuations(aText);

        ArrayList<String> ttext = tagger.tag(aText);
        ArrayList<String> vbps = new ArrayList<String>();

        for(String word:ttext) {
            if(word.startsWith("VB") /*|| word.startsWith("VB")*/) {
            //if(word.startsWith("IN") == false) {
                word = word.toLowerCase();
                word = removePunctuations(word);
                //if(word.contains("nnps") && word.endsWith("s")) {
                //    word = word.replaceAll("nnps", "nnp");
                //    word = word.substring(0, word.length() - 1);
                //}
                if(vbps.contains(word) == false && word.contains("<") == false) {
                    vbps.add(word);
                }
            }
        }

        return vbps;
    }

	void removePunctuationsTest() {
		//String word = "a-senator.";
		//String word = "british-legion,";
		//String word = "'a-profound";
		String word = "president-trump’s";


		word = removePunctuations(word);
		System.out.println(word);
	}
    private static final String punctuations [] = {
        "\\.", //is a period or full stop
        "\\,", //is a comma
        "\\?", //is a question mark
        "\\!", //is an exclamation mark
        "\\'", "’", //is an apostrophe or single quote mark
        "\"", //is a quotation mark/inverted comma
        ":", //is a colon
        ";", //is a semicolon
        "\\.\\.\\.", //is an ellipsis mark
        "\\-", //is a hyphen
        "\\–", //is an en dash
        "\\—", //is an em dash
        "\\(", "\\)", //are parentheses or curved brackets
        "\\[", "\\]", //are brackets or square brackets.
        "\r\n", "\n",
    };
    private String removePunctuations(String word) {
        int limit = punctuations.length;
        String nothing = "";
        for(int index = 0; index < limit; index++) {
            String punctuation = punctuations[index];
            //if(word.contains(punctuation)) {
                word = word.replaceAll(punctuation, nothing);
            //}
        }
        return word;
    }

    void nounTest() {
    	String text = "FDA greenlights new coronavirus antigen test The Food and Drug Administration (FDA) announced Saturday it gave emergency authorization of an antigen test that can quickly detect coronavirus proteins from the swabs of infected patients.";
    	String part = "antigen";
    	part = part.toLowerCase();
    	String words[] = text.split(" ");
    	ArrayList<String> sentance = new ArrayList<String>();
    	for(String word:words) {
    		word = word.toLowerCase();
    		word = removePunctuations(word);
    		sentance.add(word);
    	}

    	boolean status = isNoun(part, sentance);
    	System.out.println(status);
    }

    private boolean isNoun(String aWord, ArrayList<String> aSentance) {
        int nwords = aSentance.size();
        int top20 = (int)((double)10 * nwords / 100);
        //int bottom20 = nwords - top20;
        int position = 1;
        boolean match = false;

        for(String word : aSentance) {
            System.out.println(word + "," + position);
            if(word.equals(aWord) && (position <= top20 /*|| position >= bottom20*/)) {
                match = true;
            }
            position++;
        }

        return match;
    }

	void quotesRemovalTest() {
		String message = "The \"king\" walked around the palace";
		System.out.println(message);
		message = message.replaceAll("\"", "\\\\\"");
		System.out.println(message);
	}

	int hashCodex(String mesg) {
		int limit = mesg.length();
		int code = 0;
		for(int index = 0; index < limit; index++) {
			code ^= mesg.charAt(index);
		}
		return code;
	}
}