//package com.newsobotics.rss;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class RSSAggregator {
    private volatile LinkedHashMap<String, LinkedHashMap<String,RSSEntry>> content = null;
    //private volatile LinkedHashMap<String, LinkedHashMap<String,Integer>> srcStats = null;

    //private volatile LinkedHashMap<String,Integer>         wrdStats = null;
    //private volatile LinkedHashMap<String,HashSet<String>> wrdSeqns = null;
    //private volatile LinkedHashMap<String,Integer> sources = null;
    HashSet<String> dupes;

    //HashMap seqns = new HashMap<String,Integer>();
    //HashMap kgraph = new HashMap<String,Integer>();
    //HashMap knoise = new HashMap<String,Integer>();
    POSTaggingExample tagger = new POSTaggingExample();
    //HashMap<Integer, HashSet<String>> contextBags;
    //HashMap<HashSet<String>, ArrayList<Integer>> bagContexts;
    //HashMap<String, ArrayList<String>> relations;
    //HashSet<String> ckeys;

    HashMap<String, Integer> entityFrequency;
    HashMap<String, Integer> actionFrequency;
    private static int runCount = 0;

    public static void main(String[] args) {
        if(args.length < 1) {
            System.out.println("java RSSAggregator [CORRELATE] [HTML|CSV] <rss-feed-list-file.txt>\n");
            return;
        }

        ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);

        Runnable task1 = () -> {
            runCount++;
            System.err.println("Running...RSSAggregator - runCount : " + runCount);
            new RSSAggregator(args);
        };

        // init Delay = 5, repeat the task every 1 second
        ScheduledFuture<?> scheduledFuture = ses.scheduleAtFixedRate(task1, 5, 60*15, TimeUnit.SECONDS);

        while (true) {
            System.err.println("RSSAggregator :" + runCount);
            try {
                Thread.sleep(1000);
            }catch(Exception e) {
                e.printStackTrace();
            }
            //if (runCount == 5) {
            //    System.err.println("RSSAggregator: Count is 5, cancel the scheduledFuture!");
            //    scheduledFuture.cancel(true);
            //    ses.shutdown();
            //    break;
            //}
        }
    }

    RSSAggregator(String args[]) {
        String feeds = args[0];
        String source = "";
        content  = new LinkedHashMap();
        //srcStats = new LinkedHashMap();
        //wrdStats = new LinkedHashMap();
        //wrdSeqns = new LinkedHashMap();
        //sources = new LinkedHashMap();

        dupes = new HashSet<String>();
        //seqns = new HashMap<String,Integer>();
        //contextBags = new HashMap<Integer, HashSet<String>>();
        //bagContexts = new HashMap<HashSet<String>, ArrayList<Integer>>();
        //relations = new HashMap<String,ArrayList<String>>();
        //ckeys = new HashSet<String>();
        entityFrequency = new HashMap<String,Integer>();
        actionFrequency = new HashMap<String,Integer>();

        int sourceCount = 0;
        
        try {

            BufferedReader br = new BufferedReader(new FileReader(feeds));
            String line = "";
            while((line = br.readLine()) != null) {
                if(line.isEmpty() == true || line.startsWith("#") == true) {
                    if(line.startsWith("##") == true || line.startsWith("#@") == true) {
                        //System.out.println(line);
                        source = line.substring(2);
                        //sources.put(source, new Integer(sourceCount));
                        sourceCount++;
                    }
                    continue;
                }
                //System.out.println(line);
                String token[] = line.split("\\|");

                String category = token[0];
                String rssURL = token[1];
                //RSSReader rd = new RSSReader(new String[] {token[0], token[1]});
                XMLParserSAX rd = new XMLParserSAX(new String[] {source, category, rssURL});
                //aggregate(category, rd.getEntries());
                aggregate2(category, rd.getEntries());
            }

            br.close();

            doPackaging();
            //NewsSorter s = new NewsSorter(content);
            //s.sort();
            NewsPrinter p = new NewsPrinter(content, null, null);
            p.print(args[2]);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    /*void aggregate(String category, List<RSSEntry> entries) {
        if(entries == null) {
            return;
        }
        try {
            String fileName = category +".rss.txt";
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true));
            for(RSSEntry entry : entries) {
                bw.write(entry.toString() + "\n");
            }
            bw.close();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }*/

    void aggregate2(String category, List<RSSEntry> entries) {
        if(entries == null) {
            return;
        }

        for(RSSEntry entry : entries) {

            //1. store content according to its category.
            String title = "" + ((Integer)entry.getBarcode()).intValue();
            //String link = entry.getLink();
            String source = entry.getSource();
            LinkedHashMap map = content.get(category);
            if(map == null) {
                map = new LinkedHashMap<String, RSSEntry>();
                content.put(category, map);
            }
            map.put(title, entry);

            //2. store content word statistics for all categories
            /*title = entry.getTitle() + " " + entry.getDescription();
            String words[] = title.split(" ");
            //int nwords = words.length;
            for(String word: words) {
                word = word.toLowerCase();
                Integer wc = (Integer)wrdStats.get(word);
                if(wc == null) {
                    wc = new Integer(1);
                } else {
                    wc = new Integer(wc.intValue() + 1);
                }
                if(isAlphaNumeric(word)) {
                    wrdStats.put(word, wc);
                }
            }*/

            //3. store content source statistics to its category.
            /*LinkedHashMap countMap = srcStats.get(category);
            if(countMap == null) {
                countMap = new LinkedHashMap<String, Integer>();
                srcStats.put(category, countMap);                
            }
            Integer count = (Integer)countMap.get(source);
            if(count == null) {
                count = new Integer(1);
            } else {
                int value = count.intValue();
                count = new Integer(++value);
            }
            countMap.put(source, count);*/
        }
    }

    /*private void analyzeStats(String aCorrelate) {

        //loadRelations();

        Set<String> categories = srcStats.keySet();
        for(String category : categories) {
            LinkedHashMap map = srcStats.get(category);
            int size = map.size();

            List<String> csrcs = new ArrayList<>(map.keySet());
            int scount = csrcs.size();
            int total = 0;
            for(int index = 0; index < scount; index++){
                String csr = csrcs.get(index);
                Integer count = (Integer)map.get(csr);
                total += count.intValue();
            }
            for(int index = 0; index < scount; index++){
                String csr = csrcs.get(index);
                Integer count = (Integer)map.get(csr);
                int slots = count.intValue() * 40 / total;
                //map.put("#"+csr, new Integer(slots));
                if(scount > 5) {
                    if(index <= (scount / 2)) {
                        slots *= 2;
                    } else {
                        slots /= 2;
                    }
                }
                //slots = slots <= 0 ? 1 : slots;
                slots += 1;

                //reduce slots to half
                //slots /= 2;
                map.put("#"+csr, new Integer(slots));
            }
        }

        //System.out.println("<!--" + srcStats + "-->");
        //System.out.println("<!--" + wrdStats + "-->");
        //System.out.println(sources);
        Set<String> categories = content.keySet();
        for(String category : categories) {
            LinkedHashMap map = content.get(category);
            int size = map.size();
            List<String> keys = new ArrayList<>(map.keySet());
            int limit = keys.size();
            //System.err.println("adding related entries for: " + category + ":" + limit);
            for(int index = 0; index < limit; index++) {
                String key = keys.get(index);
                if(dupes.contains(key)) {
                    map.remove(key);
                } else {
                    dupes.add(key);
                }
                //if(aCorrelate.equals("CORRELATE")) {
                //    addRelatedEntry(map, keys, index, limit);
                //}
                //RSSEntry entry = (RSSEntry)map.get(key);
                //if(entry != null) {
                //    addRelatedEntry(category, entry);
                //}
            }
            for(int index = 0; index < limit; index++) {
                String key = keys.get(index);
                RSSEntry entry = (RSSEntry)map.get(key);
                if(entry != null) {
                    ArrayList ritems = entry.getRelatedItems();
                    if(ritems.size() > 0) {
                        //System.err.println(entry.getBarcode() + "|" + ritems);
                        relations.put(key, ritems);
                    }
                }
            }
        }
        //System.out.println("<!--" + sortByValue(seqns) + "-->");
        //writeStatistics();
    }*/

    /*private void readStatistics() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("kg.txt"));
            String line = "";
            while((line = br.readLine()) != null) {
                String tokens[] = line.split("=");
                String key = tokens[0];
                int hits = Integer.parseInt(tokens[1]);
                if(key.startsWith("*")) {
                    key = key.substring(1);
                    kgraph.put(key, new Integer(hits));
                }else{
                    knoise.put(key, new Integer(hits));
                }
            }
            br.close();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }*/

    private void doPackaging() {
        //System.err.println(imageURLs);
        /*try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("glossary.txt"));
            //bw.write(contextBags + "\n");

            Iterator<HashSet<String>> ckeys = (Iterator<HashSet<String>>)bagContexts.keySet().iterator();
            while(ckeys.hasNext()) { 
                HashSet<String> ckey = ckeys.next();
                ArrayList<Integer> cvalue = (ArrayList<Integer>)bagContexts.get(ckey); 
                if(cvalue.size() >= 4) {
                    bw.write("\n" + ckey + "=\n\t" + cvalue);
                }
            } 
            bw.close();
        }catch(Exception e) {
            e.printStackTrace();
        }*/
        /*try {
            BufferedWriter bw1 = new BufferedWriter(new FileWriter("news.csv"));
            BufferedWriter bw2 = new BufferedWriter(new FileWriter("terms.csv"));
            BufferedWriter bw3 = new BufferedWriter(new FileWriter("news-terms.csv"));
            BufferedWriter bw4 = new BufferedWriter(new FileWriter("terms-news.csv"));
            bw1.write("id,name\n");
            bw2.write("id,name\n");
            bw3.write("newsId,termId,relation\n");
            bw4.write("termId,newsId,relation\n");
            Set<String> categories = srcStats.keySet();
            categories = content.keySet();
            HashMap<String,String> newsTokens = new HashMap<String,String>();
            HashMap<String,String> termTokens = new HashMap<String,String>();
            int ntoken = 1;
            int ttoken = 1;
            for(String category : categories) {
                LinkedHashMap map = content.get(category);
                int size = map.size();
                List<String> keys = new ArrayList<>(map.keySet());
                int limit = keys.size();
                System.err.println("adding related entries for: " + category + ":" + limit);
                for(int index = 0; index < limit; index++) {
                    String key = keys.get(index);
                    RSSEntry entry = (RSSEntry)map.get(key);
                    if(entry == null) {
                        continue;
                    }
                    String title = entry.getTitle();
                    String description = entry.getDescription();
                    String text = title;
                    if(description.contains("|") == false) {
                        text += " " + description;
                    }
                    ArrayList<String> nnps = getEntities(text, entry);
                    entry.setRelatedItems(nnps);

                    doCluster(entry);

                    //bw.write("create (n:News{Name:\"" + key + "\"});\n");
                    String nkey = newsTokens.get(key);
                    if(nkey == null) {
                        newsTokens.put(key, "" + ntoken);
                        bw1.write(ntoken + "," + key + "\n");
                        ntoken++;
                    }
                    for(String rel:nnps) {
                        //bw.write("merge (n:Term{Name:\"" + rel + "\"});\n");
                        String tkey = termTokens.get(rel);
                        if(tkey == null) {
                            termTokens.put(rel, "" + ttoken);
                            bw2.write(ttoken + "," + rel + "\n");
                            //bw.write("merge (n:Term{Name:\"" + rel + "\"});\n");
                            ttoken++;
                        }
                    }

                    nkey = newsTokens.get(key);
                    for(String rel:nnps) {
                        String tkey = termTokens.get(rel);
                        //bw.write("MATCH (a:News),(b:Term) WHERE a.Name = '" + key + "' AND b.Name = '" + rel + "' CREATE (a)-[r:RELATED_TO]->(b) RETURN type(r);\n");
                        bw3.write(nkey + "," + tkey + ",REFERS_TO\n");
                        bw4.write(tkey + "," + nkey + ",REFERD_BY\n");
                    }
                }
            }
            bw1.close();
            bw2.close();
            bw3.close();
            bw4.close();
        }catch(Exception e) {
            e.printStackTrace();
        }*/

        //1. remove duplicates
        //2. create preidctions
        //3. TF/IDF
        //4. cluster
        //5. Sort

        Set<String> categories = content.keySet();
        for(String category : categories) {
            LinkedHashMap map = content.get(category);
            int size = map.size();
            List<String> keys = new ArrayList<>(map.keySet());
            int limit = keys.size();
            //System.err.println("adding related entries for: " + category + ":" + limit);
            for(int index = 0; index < limit; index++) {
                String key = keys.get(index);
                if(dupes.contains(key)) {
                    map.remove(key);
                } else {
                    dupes.add(key);
                }
            }
        }

        LinkedHashMap<String,RSSEntry> predicts = new LinkedHashMap<String,RSSEntry>();
        for(String category : categories) {
            LinkedHashMap map = content.get(category);
            int size = map.size();
            List<String> keys = new ArrayList<>(map.keySet());
            int kcount = keys.size();
            if(kcount < 12) {
                continue;
            }
            //System.out.println("<li class=\"nav-item\">\n  <a class=\"nav-link\" href=\"#" + category +"\">"+category+"</span></a></li>\n");
            String tcategory = removePunctuations(category);
            //System.out.println("\t<span class=\"card-text\"><a href=\"#\" onClick=\"myFunction('"+tcategory+"')\">"+category+"</a>&nbsp;|&nbsp;</span>");

            int index = 0;
            while(index < kcount) {
                String key = keys.get(index);
                RSSEntry entry = (RSSEntry)map.get(key);
                String title = entry.getTitle();
                String description = entry.getDescription();
                title = title.toLowerCase();
                description = description.toLowerCase();
                if(title.contains("predict") || description.contains("predict") ||
                    title.contains("might") || description.contains("might")) {
                    predicts.put(key, entry);
                }
                index++;
            }
        }
        content.put("Predictions", predicts);


        for(String category : categories) {
            LinkedHashMap map = content.get(category);
            int size = map.size();
            List<String> keys = new ArrayList<>(map.keySet());
            int limit = keys.size();
            System.err.println("calculating TF for entries in: " + category + ":" + limit);
            for(int index = 0; index < limit; index++) {
                String key = keys.get(index);
                RSSEntry entry = (RSSEntry)map.get(key);
                if(entry == null) {
                    continue;
                }
                String title = entry.getTitle();
                String description = entry.getDescription();
                String text = title;
                if(description.contains("|") == false) {
                    text += " " + description;
                }
                ArrayList<String> nnps = getEntities(text, entry);
                entry.setRelatedEntities(nnps);
                ArrayList<String> vbps = getActions(text, entry);
                entry.setRelatedActions(vbps);

                doTF(entry);
            }
        }

        //System.out.println("/* " + actionFrequency + "*/");

        for(String category : categories) {
            LinkedHashMap map = content.get(category);
            int size = map.size();
            List<String> keys = new ArrayList<>(map.keySet());
            int limit = keys.size();
            System.err.println("calculating scores(TF/IDF) for entries in: " + category + ":" + limit);
            for(int index = 0; index < limit; index++) {
                String key = keys.get(index);
                RSSEntry entry = (RSSEntry)map.get(key);
                if(entry == null) {
                    continue;
                }
                String title = entry.getTitle();
                String description = entry.getDescription();
                String text = title;
                if(description.contains("|") == false) {
                    text += " " + description;
                }

                doTFIDF(entry);
            }
        }

        for(String category : categories) {
            doCluster(category, content.get(category));
        }

        for(String category : categories) {
            LinkedHashMap map = content.get(category);
            int size = map.size();
            List<String> keys = new ArrayList<>(map.keySet());
            int limit = keys.size();
            System.err.println("sorting entries in: " + category + ":" + limit);
            content.put(category, sortByScore(map));
        }

        /*try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("allocations.txt"));
            bw.write(srcStats+"\n");
            bw.close();
        }catch(Exception e) {
            e.printStackTrace();
        }*/
        //List<String> keys = new ArrayList<>(relations.keySet());
        //for(String key : keys) {
        //    ArrayList<String> rels = relations.get(key);
        //    if(rels != null && rels.size() > 1) {
        //        System.out.println(key + ":" + rels);
        //    }
        //}
        //for(String key : keys) {
        //    ArrayList<String> rels = relations.get(key);
        //    if(rels != null && rels.size() <= 1) {
        //        System.out.println(key + ":" + rels);
        //    }
        //}

        //System.out.println(ckeys);
        //System.out.println(relations);
        //System.out.println("<!--" + sortByValue(seqns) + "-->");
        //System.err.println(imageURLs);
        /*try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("statistics.txt"));
            bw.write("<!--" + srcStats + "-->\n");
            List<String> keys = new ArrayList<>(seqns.keySet());
            for(String key:keys) {
                Integer nhits = (Integer)knoise.get(key);
                Integer khits = (Integer)kgraph.get(key);
                if(nhits == null && khits == null) {
                    bw.write(key + "=" + seqns.get(key) + "\n");
                }
            }
            bw.close();
        }catch(Exception e) {
            e.printStackTrace();
        }*/
    }

    private void doTF(RSSEntry aEntry) {
        ArrayList<String> nnps = aEntry.getRelatedEntities();
        for(String term : nnps) {
            Integer frequency = entityFrequency.get(term);
            if(frequency == null) {
                frequency = new Integer(1);
            } else {
                frequency = frequency.intValue() + 1;
            }
            entityFrequency.put(term, frequency);
        }

        ArrayList<String> vbps = aEntry.getRelatedActions();
        for(String term : vbps) {
            Integer frequency = actionFrequency.get(term);
            if(frequency == null) {
                frequency = new Integer(1);
            } else {
                frequency = frequency.intValue() + 1;
            }
            actionFrequency.put(term, frequency);
        }
    }

    private void doTFIDF(RSSEntry aEntry) {
        List<String> keys = new ArrayList<>(entityFrequency.keySet());
        int maxTerms = keys.size();

        ArrayList<String> nnps = aEntry.getRelatedEntities();
        int nterms = nnps.size();
        double score = 0;
        for(String term : nnps) {
            Integer frequency = entityFrequency.get(term);
            if(frequency != null) {
                score += frequency.intValue();
            }
        }
        score = score * nterms / maxTerms;
        aEntry.setScore(score);


        keys = new ArrayList<>(actionFrequency.keySet());
        maxTerms = keys.size();

        ArrayList<String> vbps = aEntry.getRelatedActions();
        nterms = vbps.size();
        score = 0;
        for(String term : vbps) {
            Integer frequency = actionFrequency.get(term);
            if(frequency != null) {
                score += frequency.intValue();
            }
        }
        score = score * nterms / maxTerms;
        aEntry.setSentiment(score);
    }

    private void doCluster(String aCategory, LinkedHashMap<String,RSSEntry> aMap) {
        int size = aMap.size();
        List<String> keys = new ArrayList<>(aMap.keySet());
        int blimit = keys.size();
        //System.err.println("before clustering entries in: " + aCategory + ":" + limit);

        int maxScore = 0;
        List<String> removals = new ArrayList<String>();
        for(int first = 0; first < blimit - 1; first++) {
            String fkey = keys.get(first);
            RSSEntry firstEntry = (RSSEntry)aMap.get(fkey);
            if(firstEntry == null) {
                continue;
            }
            for(int second = first + 1; second < blimit; second++) {
                String skey = keys.get(second);
                RSSEntry secondEntry = (RSSEntry)aMap.get(skey);
                if(secondEntry == null || secondEntry.getParent() != null) {
                    continue;
                }
                int score = (int)calculateSimilarity(firstEntry, secondEntry);
                if(score >= 40) {
                    RSSEntry entry = firstEntry;
                    do {
                        secondEntry.setParent(entry);
                        if(removals.contains(skey) == false) {
                            removals.add(skey);
                        }
                        if(entry.getParent() != null) {
                            entry = entry.getParent();
                        }
                    } while(entry.getParent() != null);
                    entry.addChild(secondEntry);
                }
                if(score > maxScore) {
                    maxScore = score;
                }
            }
            if(maxScore < 40) {
                
            }
        }
        for(String rkey:removals) {
            aMap.remove(rkey);
        }
        keys = new ArrayList<>(aMap.keySet());
        int alimit = keys.size();

        System.err.println("finished clustering entries in: " + aCategory + ":" +
            blimit + "," + alimit + "," + (alimit * 100 / blimit) + "%");

        /*ArrayList<String> nnps = aEntry.getRelatedTerms();

        if(nnps.size() < 1) {
            return;
        }

        String key = ""+nnps;
        ArrayList<String> items = relations.get(key);
        if(items == null) {
            items = getNearestMatch(relations, key);
            if(items == null) {
                items = new ArrayList<String>();
            } else {
                if(ckeys.contains(key) == false) {
                    ckeys.add(key);
                }
            }
        } else {
            //System.out.println(key);
            if(ckeys.contains(key) == false) {
                ckeys.add(key);
            }
        }

        String barcode = "" + aEntry.getBarcode();
        if(items.contains(barcode) == false) {
            items.add(barcode);
        }
        relations.put(key, items);*/
    }

    /*ArrayList<String> getNearestMatch(HashMap<String, ArrayList<String>> aRelations, String aKey) {
        aKey = aKey.substring(1, aKey.length() - 1);
        String aknnps [] = aKey.split(",");
        int aksize = aknnps.length;
        HashSet<String> bag = new HashSet<String>();
        for(String aknnp: aknnps) {
            aknnp = aknnp.trim();
            bag.add(aknnp);
        }

        List<String> keys = new ArrayList<>(aRelations.keySet());
        for(String key : keys) {
            key = key.substring(1, key.length() - 1);
            String nnps [] = key.split(",");
            int hits = 0;
            for(String nnp: nnps) {
                nnp = nnp.trim();
                if(bag.contains(nnp)) {
                    hits++;
                }
            }
            int score = hits * 100 / aksize;
            if(score >= 50) {
                //System.out.println("in:" + aKey + ",out:" + key);
                return aRelations.get(key);
            }
        }

        return null;

    }*/


    /*private static HashMap<String, Integer> sortByValue(HashMap<String, Integer> hm) { 
        // Create a list from elements of HashMap 
        List<Map.Entry<String, Integer> > list = 
               new LinkedList<Map.Entry<String, Integer> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() { 
            public int compare(Map.Entry<String, Integer> o1,  
                Map.Entry<String, Integer> o2) { 
                return (o2.getValue()).compareTo(o1.getValue()); 
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>(); 
        for (Map.Entry<String, Integer> aa : list) { 
            temp.put(aa.getKey(), aa.getValue()); 
        } 
        return temp; 
    }*/ 
  
    private static LinkedHashMap<String, RSSEntry> sortByScore(LinkedHashMap<String, RSSEntry> hm) { 
        // Create a list from elements of HashMap 
        List<Map.Entry<String, RSSEntry> > list = 
               new LinkedList<Map.Entry<String, RSSEntry> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, RSSEntry> >() { 
            public int compare(Map.Entry<String, RSSEntry> o1,  
                Map.Entry<String, RSSEntry> o2) { 
                return (o2.getValue().getSentiment()).compareTo(o1.getValue().getSentiment()); 
            } 
        }); 
          
        // put data from sorted list to hashmap  
        LinkedHashMap<String, RSSEntry> temp = new LinkedHashMap<String, RSSEntry>(); 
        for (Map.Entry<String, RSSEntry> aa : list) { 
            temp.put(aa.getKey(), aa.getValue()); 
        } 
        return temp; 
    } 

    /*private static HashMap<HashSet<String>, ArrayList<Integer>> sortByValueLength(HashMap<HashSet<String>, ArrayList<Integer>> hm) { 
        // Create a list from elements of HashMap 
        List<Map.Entry<HashSet<String>, ArrayList<Integer>> > list = 
               new LinkedList<Map.Entry<HashSet<String>, ArrayList<Integer>> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<HashSet<String>, ArrayList<Integer>> >() { 
            public int compare(Map.Entry<HashSet<String>, ArrayList<Integer>> o1,  
                Map.Entry<HashSet<String>, ArrayList<Integer>> o2) { 
                int s1 = o2.getValue().size();
                int s2 = o1.getValue().size();
                int status = 0;
                if(s1 == s1) {
                    status = 0;
                } else if(s1 > s2) {
                    status = 1;
                } else {
                    status = -1;
                }
                return (status); 
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<HashSet<String>, ArrayList<Integer>> temp = new LinkedHashMap<HashSet<String>, ArrayList<Integer>>(); 
        for (Map.Entry<HashSet<String>, ArrayList<Integer>> aa : list) { 
            temp.put(aa.getKey(), aa.getValue()); 
        } 
        return temp; 
    }*/ 

    /*private void addRelatedEntry(LinkedHashMap aMap, List<String> aKeys, int aStart, int aLimit) {
        //System.err.println("addRelatedEntry:" + aStart + "," + aLimit);
        if(aStart + 1 >= aLimit) {
            return;
        }

        String key1 = aKeys.get(aStart);
        RSSEntry entry1 = (RSSEntry)aMap.get(key1);
        if(entry1 == null) {
            return;
        }
        String title1 = entry1.getTitle();
        String description1 = entry1.getDescription();
        String text1 = title1;
        if(description1.contains("|") == false) {
            text1 += " " + description1;
        }

        for(int index = aStart + 1; index < aLimit; index++) {
            String key2 = aKeys.get(index);
            RSSEntry entry2 = (RSSEntry)aMap.get(key2);
            if(entry2 == null) {
                continue;
            }
            String title2 = entry2.getTitle();
            String description2 = entry2.getDescription();
            String text2 = title2;
            if(description2.contains("|") == false) {
                text2 += " " + description2;
            }

            //if(isAlreadyRelated(entry1, entry2) == false) {
                double score = calculateSimilarity(text1, text2, entry1, entry2);
                if(score >= 42) {
                    entry1.addRelatedEntry(entry2.getBarcode(), score);
                    entry2.addRelatedEntry(entry1.getBarcode(), score);
                }
            //}
        }
    }*/


    /*private boolean isAlreadyRelated(RSSEntry aEntry1, RSSEntry aEntry2) {
        String key1 = "" + aEntry1.getBarcode();
        String key2 = "" + aEntry2.getBarcode();
        boolean status = false;

        ArrayList<String> rentries = relations.get(key1);

        if(rentries != null) {
            for(String rentry: rentries) {
                if(key2.equals(rentry)) {
                    status = true;
                    System.err.println(key1 + "," + key2);
                    break;
                }
            }
        }
        return status;
    }*/

    private ArrayList<String> getEntities(String aText, RSSEntry aEntry) {
        aText = removePunctuations(aText);

        ArrayList<String> ttext = tagger.tag(aText);
        ArrayList<String> nnps = new ArrayList<String>();

        for(String word:ttext) {
            if(word.startsWith("NNP") /*|| word.startsWith("VB")*/) {
            //if(word.startsWith("IN") == false) {
                word = word.toLowerCase();
                word = removePunctuations(word);
                if(word.contains("nnps") && word.endsWith("s")) {
                    word = word.replaceAll("nnps", "nnp");
                    word = word.substring(0, word.length() - 1);
                }
                if(nnps.contains(word) == false && word.contains("<") == false) {
                    nnps.add(word);
                }
            }
        }

        return nnps;
    }

    private ArrayList<String> getActions(String aText, RSSEntry aEntry) {
        aText = removePunctuations(aText);

        ArrayList<String> ttext = tagger.tag(aText);
        ArrayList<String> vbps = new ArrayList<String>();

        for(String word:ttext) {
            if(word.startsWith("VB") /*|| word.startsWith("VB")*/) {
            //if(word.startsWith("IN") == false) {
                word = word.toLowerCase();
                word = removePunctuations(word);
                //if(word.contains("nnps") && word.endsWith("s")) {
                //    word = word.replaceAll("nnps", "nnp");
                //    word = word.substring(0, word.length() - 1);
                //}
                if(vbps.contains(word) == false && word.contains("<") == false) {
                    vbps.add(word);
                }
            }
        }

        return vbps;
    }

    private double calculateSimilarity(RSSEntry aEntry1, RSSEntry aEntry2) {
        ArrayList<String> terms1 = aEntry1.getRelatedEntities();
        int nterms1 = terms1.size();
        if(nterms1 == 0) {
            return 0;
        }

        ArrayList<String> terms2 = aEntry2.getRelatedEntities();
        int nterms2 = terms2.size();
        int nterms = (nterms1 + nterms2) / 2;
        if(nterms2 == 0) {
            return 0;
        }

        int hits = 0;

        int freq = 0;
        List<String> keys = new ArrayList<>(entityFrequency.keySet());
        int maxTerms = keys.size();

        for(String first:terms1) {
            for(String second:terms2) {
                if(first.equals(second) || first.equals(second + "s") || (first + "s").equals(second)) {
                    hits++;
                    Integer frequency = entityFrequency.get(first);
                    if(frequency != null) {
                        freq += frequency.intValue();
                    }
                }
            }
        }
        //hits = hits * 100 / maxTerms;
        //hits += 20;
        double score = (hits * 75 / nterms) + (freq * hits * 25 / maxTerms);
        //double score = hits * 100 / (nterms1 + nterms2);
        //double score = hits * (nterms1 + nterms2) * 100 / maxTerms;
        //if(score > 40) {
        //    System.err.println("maxTerms:" + maxTerms + ", freq:" + freq + ", hits:" + hits +
        //        ", n1:" + nterms1 + ", n2:" + nterms2 + ", score:" + score);
        //}
        return score;
    }
    /*private double calculateSimilarity(String aText1, String aText2, RSSEntry aEntry1, RSSEntry aEntry2) {
        aText1 = removePunctuations(aText1);
        aText2 = removePunctuations(aText2);

        ArrayList<String> ttext1 = tagger.tag(aText1);
        ArrayList<String> ttext2 = tagger.tag(aText2);

        //HashMap<String,String> seq1 = new HashMap<String,String>();
        //HashMap<String,String> seq2 = new HashMap<String,String>();
        //System.out.println(ttext1);
        //System.out.println(ttext2);
        //1. check if bag already exists for entry, create or retrive bag
        //2. find intersection of bags
        //3. return score

        int nouns1 = 0;
        int nouns2 = 0;

        Integer barcode1 = aEntry1.getBarcode();
        Integer barcode2 = aEntry2.getBarcode();

        HashSet<String> bag1 = contextBags.get(barcode1);
        if(bag1 == null) {
            bag1 = new HashSet<String>();
            //String pword = "";
            for(String word:ttext1) {
                if(word.startsWith("NNP")) {
                    word = word.toLowerCase();
                    word = removePunctuations(word);
                    bag1.add(word);
                    nouns1++;
                }
            }
            contextBags.put(barcode1, bag1);
        } else {
            nouns1 = bag1.size();
        }

        HashSet<String> bag2 = contextBags.get(barcode2);
        if(bag2 == null) {
            bag2 = new HashSet<String>();
            //pword = "";
            //System.out.println("***");
            for(String word:ttext2) {
                if(word.startsWith("NNP")) {
                    word = word.toLowerCase();
                    word = removePunctuations(word);
                    bag2.add(word);
                    nouns2++;
                }
            }
            contextBags.put(barcode2, bag2);
        } else {
            nouns2 = bag2.size();
        }

        int hits = 0;

        HashSet<String> overlap = new HashSet<String>();
        //pword = "";
        Iterator<String> spout = bag1.iterator();
        //String singular = "";
        while(spout.hasNext()) {
            String word = spout.next();
            if(word.endsWith("s")) {
                word = word.substring(0, word.length() - 1);
                word = word.replaceAll("nnps", "nnp");
            }
            if(bag2.contains(word)) {
                overlap.add(word);
                hits++;
            }
        }

        //pword = "";
        spout = bag2.iterator();
        //singular = "";
        while(spout.hasNext()) {
            String word = spout.next();
            //String word = (String)spout.next();
            if(word.endsWith("s")) {
                word = word.substring(0, word.length() - 1);
                word = word.replaceAll("nnps", "nnp");
            }
            if(bag1.contains(word)) {
                overlap.add(word);
                hits++;
            }
        }

        double score = (double)hits * 100 / (nouns1 + nouns2);
        if(score > 42) {
            ArrayList<Integer> contexts = bagContexts.get(overlap);
            if(contexts == null) {
                contexts = new ArrayList<Integer>();
            }
            if(contexts.contains(barcode1) == false) {
                String ago = aEntry1.getReadableDate();
                boolean isOldNews = ago.contains("week") || ago.contains("month");
                if(isOldNews == false) {
                    contexts.add(barcode1);
                }
            }
            if(contexts.contains(barcode2) == false) {
                String ago = aEntry1.getReadableDate();
                boolean isOldNews = ago.contains("week") || ago.contains("month");
                if(isOldNews == false) {
                    contexts.add(barcode2);
                }
            }
            bagContexts.put(overlap, contexts);
        }

        ttext1 = null;
        ttext2 = null;
        bag1 = null;
        bag2 = null;

        //System.out.println(aText1);
        //System.out.println(aText2);
        //System.out.println(score+"\n");

        return score;
    }*/

    /*private void addRelatedEntry2(String aCategory, RSSEntry aEntry) {
        LinkedHashMap map = content.get(aCategory);
        List<String> keys = new ArrayList<>(map.keySet());

        String aTitle = aEntry.getTitle();
        String aDescription = aEntry.getDescription();
        double maxScore = 0;
        Integer maxKey = null;

        String text2 = aTitle;
        if(aDescription.contains("|") == false) {
            text2 += " " + aDescription;
        }

        for(String key: keys) {
            RSSEntry entry = (RSSEntry)map.get(key);
            if(entry.equals(aEntry)) {
                continue;
            }
            String title = entry.getTitle();
            String description = entry.getDescription();
            String text1 = title;
            if(description.contains("|") == false) {
                text1 += " " + description;
            }
            double score = calculateSimilarity(text1, text2);
            //if(score > maxScore) {
            //    maxScore = score;
            //    maxKey = entry.getBarcode();
            //}
            if(score >= 36) {
                aEntry.addRelatedEntry(entry.getBarcode(), score);
            }
        }

        //if(maxKey != null) {
        //    aEntry.addRelatedEntry(maxKey);
        //    aEntry.setScore(maxScore);
        //}

        //return maxScore;
    }*/

    /*private double calculateSimilarity2(String aText1, String aText2) {

        String words1[] = aText1.split(" ");
        String words2[] = aText2.split(" ");
        
        if(words1.length == 0 || words2.length == 0) {
            return 0;
        }

        //aText1 = removePunctuations(aText1);
        //aText2 = removePunctuations(aText2);

        HashSet bag1 = new HashSet<String>();
        HashSet bag2 = new HashSet<String>();
        HashMap seq1 = new HashMap<String,String>();
        HashMap seq2 = new HashMap<String,String>();
        ArrayList sentance1 = new ArrayList<String>();
        ArrayList sentance2 = new ArrayList<String>();
        HashSet nouns1 = new HashSet<String>();
        HashSet nouns2 = new HashSet<String>();

        String pword = "";
        int nwords = words1.length;
        int index = 0;
        int top20 = (int)((double)10 * nwords / 100);

        for(String word : words1) {
            word = word.toLowerCase();
            word = removePunctuations(word);
            bag1.add(word);
            sentance1.add(word);
            if(index <= top20) {
                nouns1.add(word);
            }
            if(pword.isEmpty() == false) {
                seq1.put(pword, word);
            }
            pword = word;
            index++;
        }

        pword = "";
        nwords = words2.length;
        index = 0;
        top20 = (int)((double)10 * nwords / 100);
        for(String word : words2) {
            word = word.toLowerCase();
            word = removePunctuations(word);
            bag2.add(word);
            sentance2.add(word);
            if(index <= top20) {
                nouns2.add(word);
            }
            if(pword.isEmpty() == false) {
                seq2.put(pword, word);
            }
            pword = word;
            index++;
        }

        int hits = 0;
        int kghits = 0;
        pword = "";
        for(String word : words1) {
            word = word.toLowerCase();
            String next = (String)seq2.get(pword);
            if(next == null) {
                next = "";
            }
            if(next.startsWith(word) || bag2.contains(word)) {
                hits++;
                if(kgraph.get(pword + "-" + word) != null || kgraph.get(word) != null) {
                    kghits ++;
                }
            }
            pword = word;
        }

        pword = "";
        for(String word : words2) {
            word = word.toLowerCase();
            String next = (String)seq1.get(pword);
            if(next == null) {
                next = "";
            }
            if(next.startsWith(word) || bag1.contains(word)) {
                hits++;
                if(kgraph.get(pword + "-" + word) != null || kgraph.get(word) != null) {
                    kghits ++;
                }
            }
            pword = word;
        }

        double score = (double)hits * 100 / (words1.length + words2.length);
        if(score < 36 && kghits > 0) {
            score *= 2.5;
        //} else if(score >= 36 && kghits <= 0) {
        //    score = 0;
        }

        if(score >= 36) {
            //System.err.println(seq1 + "-" + seq2);
            List<String> skeys = new ArrayList<>(seq1.keySet());
            for(String skey : skeys) {
                String sval = (String)seq1.get(skey);
                //if(isNoun(skey, sentance1) || isNoun(sval, sentance1)) {
                if(nouns1.contains(skey) || nouns1.contains(sval)) {
                    String kv = skey + "-" + sval;
                    Integer kvhits = (Integer)seqns.get(kv);
                    if(kvhits == null) {
                        kvhits = new Integer(1);
                    } else {
                        kvhits = new Integer(kvhits.intValue() + 1);
                    }
                    seqns.put(kv, kvhits);
                }
            }
            skeys = new ArrayList<>(seq2.keySet());
            for(String skey : skeys) {
                String sval = (String)seq2.get(skey);
                if(nouns2.contains(skey) || nouns2.contains(sval)) {
                    String kv = skey + "-" + sval;
                    Integer kvhits = (Integer)seqns.get(kv);
                    if(kvhits == null) {
                        kvhits = new Integer(1);
                    } else {
                        kvhits = new Integer(kvhits.intValue() + 1);
                    }
                    seqns.put(kv, kvhits);
                }
            }
        }
        return score;
    }

    private boolean isNoun(String aWord, ArrayList<String> aSentance) {
        int nwords = aSentance.size();
        int top20 = (int)((double)10 * nwords / 100);
        //int bottom20 = nwords - top20;
        int position = 1;
        boolean match = false;

        for(String word : aSentance) {
            if(word.equals(aWord) && (position <= top20)){}
                //|| position >= bottom20)) {
                //System.err.println(word + "," + position);
                match = true;
                break;
            }
            position++;
        }

        return match;
    }*/

    private static final String punctuations [] = {
        "\\.", //is a period or full stop
        "\\,", //is a comma
        "\\?", //is a question mark
        "\\!", //is an exclamation mark
        "\\'", "’", //is an apostrophe or single quote mark
        "\"", //is a quotation mark/inverted comma
        ":", //is a colon
        ";", //is a semicolon
        "\\.\\.\\.", //is an ellipsis mark
        "\\-", //is a hyphen
        "\\–", //is an en dash
        "\\—", //is an em dash
        "\\(", "\\)", //are parentheses or curved brackets
        "\\[", "\\]", //are brackets or square brackets.
        "\r\n", "\n",
    };
    private String removePunctuations(String word) {
        int limit = punctuations.length;
        String nothing = "";
        for(int index = 0; index < limit; index++) {
            String punctuation = punctuations[index];
            //if(word.contains(punctuation)) {
            word = word.replaceAll(punctuation, nothing);
            //}
        }
        return word;
    }

    private boolean isAlphaNumeric(String word) {
        boolean status = true;
        int limit = word.length();
        for(int index = 0; index < limit; index++) {
            char ch = word.charAt(index);
            if(Character.isLetterOrDigit(ch) == false) {
                status = false;
            }
        }
        return status;
    }
}
