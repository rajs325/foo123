import java.io.*;
import java.util.*;
import java.net.*;


class Curl {
    //String branchName="name";
    //String branchId="bid";
    //String sourceBranch="sb"
    //String alias="ppp"

    //String[] command = {"curl" "-k" "-i" "-X" POST "-H" "Content-Type: multipart/form-data" --cookie "rsession=your rsession" "Content-Type:application/json" --data{branchName+":"+branchId":"+sourceBranch":",+alias}};

    private String content;
    public static void main(String args[]) {
        new Curl(args);
    }
    Curl(String args[]){
        content = "";
        List<String> list = new ArrayList<String>();
        //String command[] = {"curl ",  args[0]};
        list.add("curl");
        list.add(args[0]);
        ProcessBuilder process = new ProcessBuilder(list); 
        Process p;
        try {
            p = process.start();
            BufferedReader reader =  new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line = null;
            while ( (line = reader.readLine()) != null) {
                builder.append(line);
                builder.append(System.getProperty("line.separator"));
            }
            content = builder.toString();
            //System.out.print(result);
        } catch (IOException e) {
            System.out.print("error");
            e.printStackTrace();
        }
    }
    Curl(String arg){
        content = "";
        try {
            boolean redirection = true;

            while(redirection == true) {
                URL url = new URL(arg);
                URLConnection connection = url.openConnection();
                BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder builder = new StringBuilder();
                String line = null;
                while ( (line = br.readLine()) != null) {
                    builder.append(line);
                    builder.append(System.getProperty("line.separator"));
                }
                content = builder.toString();
                br.close();

                String pattern = "The document has moved <A HREF=";
                if(content.contains(pattern)) {
                    int start = content.indexOf(pattern) + pattern.length() + 1;
                    int end = content.indexOf("\">", start);
                    arg = content.substring(start, end);
                    //System.err.println(start + "," + end + "," + arg);
                    redirection = true;
                } else {
                    redirection = false;
                }
            }
            //System.out.print(result);
        } catch (IOException e) {
            System.out.print("error");
            e.printStackTrace();
        }
    }
    public String getContent() {
        return content;
    }
}